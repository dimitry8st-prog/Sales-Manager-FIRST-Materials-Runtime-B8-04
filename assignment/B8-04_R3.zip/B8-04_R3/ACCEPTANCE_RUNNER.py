from pathlib import Path
import argparse,contextlib,copy,datetime,hashlib,importlib,json,sys,threading,time
ROOT=Path(__file__).resolve().parent

# Shared R3 harness checks: reject malformed dependency calls before spy/effects.
def assert_port_request(ports, name, request):
 if name not in ports.port_contracts:return
 import uuid
 spec=ports.port_contracts[name]['request']
 assert type(request) is dict and set(request)==set(spec),(name,'exact dependency keys')
 def identifier(v):
  return type(v) is str and 0<len(v)<=128 and v.strip()==v and not any(ord(c)<32 or ord(c)==127 for c in v)
 def scope(v,types,foreign_all=True):
  assert type(v) is dict,(name,'scope type')
  small={'client_id','campaign_id'};lead=small|{'lead_id','mailbox_ref','thread_id'};db={'client_id','target_id'}
  allowed=[]
  for t in types:
   if t in ('CatalogScope','WorkerScope'):allowed.append(small)
   elif t in ('LeadScope','InitialScope'):allowed.append(lead)
   elif t=='DatabaseScope':allowed.append(db)
  assert set(v) in allowed,(name,'scope keys',set(v),types)
  if set(v)==lead:
   assert ('InitialScope' in types if v['thread_id'] is None else 'LeadScope' in types),(name,'thread scope kind')
  for k,x in v.items():
   if k=='thread_id' and x is None:continue
   assert identifier(x),(name,'scope scalar',k)
  if 'campaign_id' in v:
   try:canonical=str(uuid.UUID(v['campaign_id']))
   except (ValueError,AttributeError):raise AssertionError((name,'invalid campaign UUID')) from None
   assert canonical==v['campaign_id'],(name,'noncanonical campaign UUID')
  check=v if foreign_all else {k:v[k] for k in ('client_id','campaign_id')}
  assert all(k in ports.fixture_scope and ports.fixture_scope[k]==x for k,x in check.items()),(name,'foreign scope')
 for k,t in spec.items():
  v=request[k]
  if k=='scope':scope(v,t.split('|'));continue
  if t.startswith('list['):
   assert type(v) is list,(name,k,'expected list')
   if t=='list[LeadScope|InitialScope]':
    for item in v:scope(item,['LeadScope','InitialScope'],foreign_all=False)
    encoded=[json.dumps(item,sort_keys=True,separators=(',',':'),ensure_ascii=False) for item in v]
    assert len(encoded)==len(set(encoded)),(name,k,'duplicate scopes')
   continue
  if t=='id':assert identifier(v),(name,k,'invalid id')
  elif t=='rev':assert type(v) is int and v>=0,(name,k,'invalid revision')
  elif t=='sha256':assert type(v) is str and len(v)==64 and all(c in '0123456789abcdef' for c in v),(name,k,'invalid hash')
  elif t=='timestamp':
   assert type(v) is str,(name,k,'invalid timestamp')
   try:stamp=datetime.datetime.fromisoformat(v.replace('Z','+00:00'))
   except (ValueError,TypeError):raise AssertionError((name,k,'invalid timestamp')) from None
   assert stamp.utcoffset() is not None,(name,k,'naive timestamp')
  elif '|' in t:assert type(v) is str and v in t.split('|'),(name,k,'invalid enum')
  elif t=='RECOVER_OR_ISOLATED':assert v==t,(name,k,'invalid mode')
  elif t in ('InboxEvent','Material','Schedule','ProviderObservation','Evidence','IsolatedTarget'):
   assert type(v) is dict,(name,k,'invalid named DTO type')

class MissingDependency(RuntimeError):pass
class Ports:
 def __init__(self,fixture):
  self.auth=copy.deepcopy(fixture.get('auth',{'authenticated':True,'capabilities':['*'],'client_id':'client-test'}))
  self.policy={'lease_ttl_seconds':60,'renew_margin_seconds':10,'connect_timeout_seconds':2,'statement_timeout_seconds':3,'lock_timeout_seconds':2}
  self.now=datetime.datetime.fromisoformat(fixture.get('now','2026-10-16T12:00:00+00:00'))
  self.target=fixture.get('target',{'isolated':True,'synthetic_data_only':True,'schema':'b8_test'})
  self.fixture_request=copy.deepcopy(fixture['request']);self.port_contracts=json.loads((ROOT/'PORT_CONTRACTS.json').read_text());self.fixture_scope=fixture['fixture_scope'];self.state=copy.deepcopy(fixture.get('seed',{}));self.responses=copy.deepcopy(fixture.get('responses',{}));self.effects=copy.deepcopy(fixture.get('effects',{}));self.calls=[];self.writes=[];self.lock=threading.RLock();self.barriers={}
 @contextlib.contextmanager
 def transaction(self,scope):
  if isinstance(scope,dict) and scope!=self.fixture_scope:raise PermissionError('foreign scoped repository view')
  with self.lock:
   before=copy.deepcopy(self.state);n=len(self.writes)
   try:yield self
   except BaseException:self.state=before;del self.writes[n:];raise
 def get(self,bucket,key):return copy.deepcopy(self.state.get(bucket,{}).get(key))
 def put(self,bucket,key,value):self.state.setdefault(bucket,{})[key]=copy.deepcopy(value);self.writes.append((bucket,key,copy.deepcopy(value)))
 def remove(self,bucket,key):self.state.setdefault(bucket,{}).pop(key,None);self.writes.append((bucket,key,None))
 def scan(self,bucket):return list(copy.deepcopy(self.state.get(bucket,{})).items())
 def call(self,name,request):
  assert_port_request(self,name,request)
  if name not in self.port_contracts:raise MissingDependency(name)
  spec=self.port_contracts[name]['request']
  assert type(request) is dict and set(request)==set(spec),(name,'dependency request keys',set(request),set(spec))
  for k,t in spec.items():
   v=request[k]
   if k=='scope':
    assert type(v) is dict and v and all(k in self.fixture_scope and self.fixture_scope[k]==x for k,x in v.items()),(name,'foreign scope',v)
    if t=='InitialScope':assert v.get('thread_id','missing') is None and set(v)=={'client_id','campaign_id','lead_id','mailbox_ref','thread_id'}
    if t=='LeadScope':assert v.get('thread_id') is not None and set(v)=={'client_id','campaign_id','lead_id','mailbox_ref','thread_id'}
    if t in ('CatalogScope','WorkerScope'):assert set(v)=={'client_id','campaign_id'}
    if t=='DatabaseScope':assert set(v)=={'client_id','target_id'}
   if t in ('id','sha256','timestamp'):assert isinstance(v,str) and v and v.strip()==v,(name,k,'invalid scalar')
   if t=='rev':assert type(v) is int and v>=0,(name,k,'invalid rev')
   if k in ('action_id','event_id','provider_event_id','request_id','task_id','source_ref','evidence_ref','payload_ref','bundle_ref','version') and k in self.fixture_request:assert v==self.fixture_request[k],(name,k,'identity changed')
  self.calls.append((name,copy.deepcopy(request)))
  if name not in self.responses:raise MissingDependency(name)
  for bucket,rows in self.effects.get(name,{}).items():
   for key,patch in rows.items():self.put(bucket,key,{**(self.get(bucket,key) or {}),**patch})
  value=self.responses[name]
  if isinstance(value,dict) and '$state' in value:return self.get(value['$state']['bucket'],value['$state']['key'])
  if isinstance(value,dict) and '$raise' in value:raise RuntimeError(value['$raise'])
  return copy.deepcopy(value)
 def hook(self,name):
  if name in self.barriers:
   entered,release=self.barriers[name];entered.set()
   if not release.wait(5):raise RuntimeError('barrier timeout')
 def provider_gate(self,scope):return self.transaction(scope)
 def invalidate(self,scopes,callback):
  # sorted complete scope list must come from authoritative enumerator, not caller data
  with self.transaction(scopes):return callback(self)
def subset(want,actual):
 if isinstance(want,dict):return isinstance(actual,dict) and all(k in actual and subset(v,actual[k]) for k,v in want.items())
 return want==actual
def check_bytes():
 m=json.loads((ROOT/'PACKAGE_SHA256.json').read_text());bad=[p for p,v in m.items() if not (ROOT/p).is_file() or hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=v]
 # Candidate work is allowed outside packaged files, but no supplied fixture/source alteration.
 if bad:raise AssertionError('changed issued files: '+repr(bad))
def cp0():
 check_bytes();c=json.loads((ROOT/'CONTRACT.json').read_text());cases=json.loads((ROOT/'acceptance/fixtures.json').read_text())
 assert c['status']=='READY_TO_DEVELOP' and c['operations'] and cases
 ports=json.loads((ROOT/'PORT_CONTRACTS.json').read_text());assert set(c['dependency_ports'])<=set(ports),'unfrozen required port'
 for op in c['operations']:assert any(f['operation']==op and f['expect']['status'] in ('OK','REPLAY') for f in cases),'operation missing positive acceptance: '+op
 assert set(c['capabilities'])==set(c['operations'])
 for f in cases:
  assert f['operation'] in c['operations'];assert f['expect']['status']
  keys=set(c['operations'][f['operation']])|{'scope'}
  if f.get('valid_shape',True):assert set(f['request'])==keys,(f['name'],keys)
  assert set(f['request']['scope'])==set(c['scope_fields'])
  if f.get('initial_scope'):assert f['request']['scope']['thread_id'] is None
 import subprocess
 r=subprocess.run([sys.executable,str(ROOT/'reference_source/tests/test_first_decision.py')],capture_output=True,text=True,cwd=ROOT/'reference_source',env={**__import__('os').environ,'PYTHONPATH':str(ROOT/'reference_source')})
 print(r.stdout+r.stderr)
 assert r.returncode==0,'frozen F103 baseline failed'
 for suite in ['test_first_binding.py','test_language_registry.py']:
  r=subprocess.run([sys.executable,str(ROOT/'reference_source/tests'/suite)],capture_output=True,text=True,cwd=ROOT/'reference_source',env={**__import__('os').environ,'PYTHONPATH':str(ROOT/'reference_source')});print(r.stdout+r.stderr);assert r.returncode==0,suite
 r=subprocess.run([sys.executable,str(ROOT/'SOURCE_SCOPE_SMOKE.py')],capture_output=True,text=True);print(r.stdout+r.stderr);assert r.returncode==0,'F114 original initial scope smoke'
 r=subprocess.run([sys.executable,str(ROOT/'tooling/SOURCE_MATERIALS_PROBE.py')],capture_output=True,text=True);print(r.stdout+r.stderr);assert r.returncode==0,'material codec/source feasibility'
 print('CP0 PACKAGE/CONTRACT/FIXTURES + FROZEN SOURCE BASELINES OK; candidate implementation NOT_RUN')
def cp1(module):
 sys.path.insert(0,str(ROOT/'solution'));sys.path.insert(0,str(ROOT/'reference_source'))
 try:m=importlib.import_module(module)
 except ModuleNotFoundError as e:
  if e.name in (module,module.split('.')[0]):print('NOT_IMPLEMENTED: expected candidate module '+module);return 3
  raise
 for f in json.loads((ROOT/'acceptance/fixtures.json').read_text()):
  ports=Ports(f);service=m.create_service(ports)
  before=copy.deepcopy(ports.state)
  try:out=service.execute(f['operation'],copy.deepcopy(f['request']))
  except MissingDependency as e:raise AssertionError(f['name']+': unknown dependency '+str(e))
  assert set(out)=={'status','data'} and subset(f['expect'],out),(f['name'],f['expect'],out)
  names=[n for n,r in ports.calls]
  if f.get('call_order'):
   positions=[names.index(n) for n in f['call_order']];assert positions==sorted(positions),(f['name'],'wrong safety call order',names)
  for name,expected in f.get('call_expect',{}).items():assert any(n==name and subset(expected,r) for n,r in ports.calls),(f['name'],'wrong scoped facade request',name)
  if f.get('require_bucket'):assert any(b==f['require_bucket'] for b,k,v in ports.writes),(f['name'],'missing durable bucket',f['require_bucket'])
  for n,count in f.get('calls',{}).items():assert names.count(n)==count,(f['name'],n,names)
  for n in f.get('forbidden_calls',[]):assert n not in names,(f['name'],n)
  if f.get('require_write'):assert ports.writes,(f['name'],'no durable replay/identity write')
  if f.get('no_write'):assert ports.state==before and not ports.writes,(f['name'],'unexpected writes')
  for bucket,expect in f.get('state_expect',{}).items():assert subset(expect,ports.state.get(bucket)),(f['name'],bucket)
  if 'repeat_expect' in f:
   prior=copy.deepcopy(ports.state);n=len(ports.calls);nw=len(ports.writes)
   repeat_request={**copy.deepcopy(f['request']),**f.get('repeat_request_update',{})}
   service=m.create_service(ports)
   again=service.execute(f['operation'],repeat_request)
   assert subset(f['repeat_expect'],again),(f['name'],'replay',again)
   if f.get('repeat_no_write'):assert ports.state==prior and len(ports.writes)==nw,(f['name'],'replay mutated')
   for name in f.get('repeat_forbidden_calls',[]):assert not any(k==name for k,v in ports.calls[n:]),(f['name'],'replayed effect',name)
  print('PASS',f['name'])
 # Deterministic STOP racing with dispatch between claim and final provider gate.
 contract=json.loads((ROOT/'CONTRACT.json').read_text())
 if contract['id']=='B8-07':
  f=next(f for f in json.loads((ROOT/'acceptance/fixtures.json').read_text()) if f['name']=='synthetic_acceptance_not_delivery')
  ports=Ports(f);entered=threading.Event();release=threading.Event();ports.barriers['before_provider_gate']=(entered,release)
  service=m.create_service(ports);result=[];errors=[]
  def run():
   try:result.append(service.execute('dispatch',copy.deepcopy(f['request'])))
   except BaseException as e:errors.append(repr(e))
  t=threading.Thread(target=run,daemon=True);t.start()
  assert entered.wait(5),'required before_provider_gate barrier not reached'
  with ports.transaction(f['request']['scope']):ports.put('authority','current',{'status':'STOPPED','revision':2})
  release.set();t.join(5)
  assert not t.is_alive() and not errors,(errors,'race hung')
  assert not any(n=='provider.send' for n,r in ports.calls),'provider started after STOP'
  assert result and result[0]['status']=='BLOCKED',result
  print('PASS deterministic STOP-before-provider race')
 # Synthetic state persistence is not a PG durability assertion.
 print('CP1 SYNTHETIC COMPONENT CASES PASS; real PG/installed gates NOT_RUN');return 0
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('stage',choices=['cp0','cp1']);p.add_argument('--module');a=p.parse_args()
 if a.stage=='cp0':cp0()
 else:
  if not a.module:p.error('--module required for cp1')
  sys.exit(cp1(a.module))
