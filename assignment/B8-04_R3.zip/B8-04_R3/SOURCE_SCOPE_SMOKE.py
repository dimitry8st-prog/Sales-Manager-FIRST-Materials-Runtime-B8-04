from pathlib import Path
import copy,json,sys
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'reference_source'))
from sales_outbound_intent import build_outbound_intent,OutboundIntentError
raw=json.loads((root/'reference_source/tests/fixtures/wave3/f114/golden_examples.json').read_text())['input']['action_input']
a=copy.deepcopy(raw);a['kind']='SEND';a['scope']['thread_id']=None
out=build_outbound_intent(a);assert out['action']['scope']['thread_id'] is None
for kind in ['REPLY','FOLLOWUP']:
 a=copy.deepcopy(raw);a['kind']=kind;a['scope']['thread_id']=None
 try:build_outbound_intent(a)
 except OutboundIntentError:pass
 else:raise AssertionError('null thread wrongly accepted for '+kind)
print('FROZEN F114 INITIAL SEND / REPLY / FOLLOWUP THREAD RULES PASS')
