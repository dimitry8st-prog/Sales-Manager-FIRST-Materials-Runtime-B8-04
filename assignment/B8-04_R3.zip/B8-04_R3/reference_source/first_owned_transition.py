"""F1-32: caller-owned PostgreSQL transition adapter (component only).

``run_owned_transition`` runs one task transition (finish / fail / defer) inside a
transaction that the *caller* already opened, and fences it with the exact lease
owner using the accepted F1-16 lease store:

    validate all input -> lease_store.assert_owned(...) -> update(conn)
    -> lease_store.finish_owned_in_tx(...) -> return the update result

The adapter never connects, commits, rolls back or closes anything, never copies
the update result and never catches downstream errors: any exception raised by a
port propagates unchanged so the caller's transaction context rolls back the task
result and the lease change together.  It cannot prove that ``update`` obeys the
contract (same ``conn`` only, no commit, no provider I/O); that is reviewed by the
integration owner.  See CONTRACT.json and INTEGRATION.md.
"""

import re
import uuid

INVALID_INPUT = "INVALID_OWNED_TRANSITION_INPUT"

TRANSITIONS = ("finish", "fail", "defer")
TASK_ID_MAX_CHARS = 128

_TASK_ID_PATTERN = re.compile(r"[A-Za-z0-9_.:-]+", re.ASCII)


def _valid_task_id(value):
    return (
        type(value) is str
        and 1 <= len(value) <= TASK_ID_MAX_CHARS
        and _TASK_ID_PATTERN.fullmatch(value) is not None
    )


def _valid_owner_token(value):
    # Canonical lower-case 8-4-4-4-12 UUID string, exactly as F1-16 accepts it.
    # Check length first: uuid.UUID also accepts compact, URN, and braced forms.
    if type(value) is not str or len(value) != 36:
        return False
    try:
        return str(uuid.UUID(value)) == value
    except ValueError:
        return False


def _valid_generation(value):
    # ``type is int`` rejects bool (a subclass of int) and other int look-alikes.
    return type(value) is int and value >= 1


def _valid_transition(value):
    return type(value) is str and value in TRANSITIONS


def _port(obj, name):
    try:
        port = getattr(obj, name, None)
    except BaseException:
        # A port that cannot be inspected is invalid, including a failing descriptor.
        return None
    return port if callable(port) else None


def _validate(conn, lease_store, task_id, owner_token, generation, transition, update):
    ok = (
        conn is not None
        and lease_store is not None
        and _port(lease_store, "assert_owned") is not None
        and _port(lease_store, "finish_owned_in_tx") is not None
        and callable(update)
        and _valid_task_id(task_id)
        and _valid_owner_token(owner_token)
        and _valid_generation(generation)
        and _valid_transition(transition)
    )
    if not ok:
        # The contract requires one field-agnostic error message for every bad input.
        raise ValueError(INVALID_INPUT)


def run_owned_transition(conn, lease_store, *, task_id, owner_token, generation, transition, update):
    """Run ``update(conn)`` fenced by the exact lease owner; return its result unchanged.

    Raises ``ValueError("INVALID_OWNED_TRANSITION_INPUT")`` for malformed own
    inputs *before* any port is called.  Every error from ``assert_owned``,
    ``update`` or ``finish_owned_in_tx`` (any ``BaseException``) propagates as is.
    ``transition`` is validated but intentionally not passed on: the SQL for each
    transition lives in the integrator's callback.
    """
    _validate(conn, lease_store, task_id, owner_token, generation, transition, update)

    lease_kwargs = dict(task_key=task_id, owner_token=owner_token, generation=generation)

    lease_store.assert_owned(conn, **lease_kwargs)
    result = update(conn)
    lease_store.finish_owned_in_tx(conn, **lease_kwargs)
    return result
