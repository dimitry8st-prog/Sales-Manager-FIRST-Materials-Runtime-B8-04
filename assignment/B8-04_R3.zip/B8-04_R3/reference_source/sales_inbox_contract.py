
"""
FIRST inbound email normalization contract.

Input schemas
-------------
binding (dict), schema_version="FIRST_INBOX_BINDING_V1":
    client_id (str): Non-empty identifier without surrounding whitespace.
    runtime_campaign_id (str): Canonical lowercase UUID string.
    mailbox_ref (str): Non-empty mailbox identifier.
    sender_email (str): Trusted mailbox email address.

envelope (dict), schema_version="FIRST_PROVIDER_EVENT_V1":
    provider (str): Non-empty provider identifier.
    provider_account_ref (str): Must equal binding.mailbox_ref.
    provider_message_id (str): Non-empty message identifier.
    provider_thread_id (str): Non-empty thread identifier.
    sender_email (str): Email address of the incoming sender.
    recipient_email (str): Must match binding.sender_email.
    received_at (str): ISO 8601 datetime with timezone.
    body_text (str): Non-empty, non-whitespace UTF-8 text,
        maximum 65536 encoded bytes.
    event_kind (str): INBOUND_MESSAGE or DELIVERY_FAILURE.

Optional envelope fields:
    in_reply_to (str | None): Non-empty string when provided.
    auto_reply_headers (dict[str, str]): Copied into the output.

Additional untrusted fields, including lead_id, auth and source_url,
are not propagated to the normalized output.

now (datetime):
    Timezone-aware datetime used for validation.
    received_at must not be more than 300 seconds in the future.

Output:
    dict with schema_version="FIRST_INBOUND_V1".
    Includes a deterministic SHA256 event_key derived from provider,
    trusted mailbox_ref and provider_message_id.

Fixtures:
    tests/fixtures/first_inbox/valid_binding.json
    tests/fixtures/first_inbox/valid_event.json

Stable error codes:
    INVALID_ENVELOPE
    INVALID_BINDING
    INVALID_ENVELOPE_SCHEMA
    INVALID_BINDING_SCHEMA
    INVALID_ID
    INVALID_UUID
    INVALID_EMAIL
    MAILBOX_MISMATCH
    RECIPIENT_MISMATCH
    INVALID_NOW
    INVALID_RECEIVED_AT
    FUTURE_TIMESTAMP
    INVALID_BODY
    BODY_TOO_LARGE
    INVALID_EVENT_KIND
    INVALID_IN_REPLY_TO
    INVALID_AUTO_REPLY_HEADERS

Error messages contain only stable codes, never raw input values.

No network, database, environment access or external calls.
Email content is untrusted data and is never executed.
"""

import hashlib
import json
import uuid

from datetime import datetime, timezone

from sales_rules import validate_email, RuleViolation


class InboxContractError(ValueError):
    """Validation error exposing a stable reason code."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def _required_id(value):
    """Validate a non-empty UTF-8 identifier."""
    if (
        not isinstance(value, str)
        or not value.strip()
        or value != value.strip()
    ):
        raise InboxContractError("INVALID_ID")

    try:
        value.encode("utf-8")
    except UnicodeEncodeError:
        raise InboxContractError("INVALID_ID") from None

    return value


def _check_email(value):
    """Validate an email address using existing project rules."""
    if not isinstance(value, str):
        raise InboxContractError("INVALID_EMAIL")

    try:
        email = validate_email(value)
    except (
        RuleViolation,
        TypeError,
        ValueError,
        AttributeError,
        UnicodeError,
    ):
        raise InboxContractError("INVALID_EMAIL") from None

    if not isinstance(email, str) or not email:
        raise InboxContractError("INVALID_EMAIL")

    try:
        email.encode("utf-8")
    except UnicodeEncodeError:
        raise InboxContractError("INVALID_EMAIL") from None

    return email


def normalize_inbound(
    envelope: dict,
    *,
    binding: dict,
    now: datetime,
) -> dict:
    """
    Validate and normalize one inbound provider event.

    Raises:
        InboxContractError: On invalid input, with a stable code.
    """

    # 1. Validate input types
    if not isinstance(envelope, dict):
        raise InboxContractError("INVALID_ENVELOPE")

    if not isinstance(binding, dict):
        raise InboxContractError("INVALID_BINDING")

    # 2. Validate schema versions
    if envelope.get("schema_version") != "FIRST_PROVIDER_EVENT_V1":
        raise InboxContractError("INVALID_ENVELOPE_SCHEMA")

    if binding.get("schema_version") != "FIRST_INBOX_BINDING_V1":
        raise InboxContractError("INVALID_BINDING_SCHEMA")

    # 3. Validate binding identifiers
    binding_ids = (
        "client_id",
        "runtime_campaign_id",
        "mailbox_ref",
    )

    for field in binding_ids:
        _required_id(binding.get(field))

    # 4. Validate envelope identifiers
    envelope_ids = (
        "provider",
        "provider_account_ref",
        "provider_message_id",
        "provider_thread_id",
    )

    for field in envelope_ids:
        _required_id(envelope.get(field))

    # 5. Validate canonical UUID
    campaign_id = binding["runtime_campaign_id"]

    try:
        parsed_uuid = uuid.UUID(campaign_id)
    except (ValueError, AttributeError, TypeError):
        raise InboxContractError("INVALID_UUID") from None

    if str(parsed_uuid) != campaign_id:
        raise InboxContractError("INVALID_UUID")

    # 6. Validate mailbox binding
    if envelope["provider_account_ref"] != binding["mailbox_ref"]:
        raise InboxContractError("MAILBOX_MISMATCH")

    # 7. Validate email addresses
    mailbox_email = _check_email(binding.get("sender_email"))
    normalized_sender = _check_email(envelope.get("sender_email"))
    normalized_recipient = _check_email(envelope.get("recipient_email"))

    if normalized_recipient != mailbox_email:
        raise InboxContractError("RECIPIENT_MISMATCH")

    # 8. Validate current time
    if not isinstance(now, datetime):
        raise InboxContractError("INVALID_NOW")

    try:
        if now.tzinfo is None or now.utcoffset() is None:
            raise InboxContractError("INVALID_NOW")

        now_utc = now.astimezone(timezone.utc)
    except (ValueError, OverflowError):
        raise InboxContractError("INVALID_NOW") from None

    # 9. Validate received_at
    received_value = envelope.get("received_at")

    if not isinstance(received_value, str):
        raise InboxContractError("INVALID_RECEIVED_AT")

    try:
        received_at = datetime.fromisoformat(
            received_value.replace("Z", "+00:00")
        )
    except (ValueError, TypeError, OverflowError):
        raise InboxContractError("INVALID_RECEIVED_AT") from None

    try:
        if (
            received_at.tzinfo is None
            or received_at.utcoffset() is None
        ):
            raise InboxContractError("INVALID_RECEIVED_AT")

        received_utc = received_at.astimezone(timezone.utc)

        future_seconds = (
            received_utc - now_utc
        ).total_seconds()
    except (ValueError, OverflowError):
        raise InboxContractError("INVALID_RECEIVED_AT") from None

    if future_seconds > 300:
        raise InboxContractError("FUTURE_TIMESTAMP")

    received_at_utc = received_utc.isoformat()

    # 10. Validate body text
    body = envelope.get("body_text")

    if not isinstance(body, str) or not body.strip():
        raise InboxContractError("INVALID_BODY")

    try:
        body_size = len(body.encode("utf-8"))
    except UnicodeError:
        raise InboxContractError("INVALID_BODY") from None

    if body_size > 65536:
        raise InboxContractError("BODY_TOO_LARGE")

    # 11. Validate event kind
    event_kind = envelope.get("event_kind")

    if (
        not isinstance(event_kind, str)
        or event_kind not in (
            "INBOUND_MESSAGE",
            "DELIVERY_FAILURE",
        )
    ):
        raise InboxContractError("INVALID_EVENT_KIND")

    # 12. Validate optional in_reply_to
    in_reply_to = envelope.get("in_reply_to")

    if in_reply_to is not None:
        if (
            not isinstance(in_reply_to, str)
            or not in_reply_to.strip()
        ):
            raise InboxContractError("INVALID_IN_REPLY_TO")

        try:
            in_reply_to.encode("utf-8")
        except UnicodeEncodeError:
            raise InboxContractError("INVALID_IN_REPLY_TO") from None

    # 13. Validate optional auto_reply_headers
    if "auto_reply_headers" in envelope:
        headers = envelope["auto_reply_headers"]

        if not isinstance(headers, dict):
            raise InboxContractError("INVALID_AUTO_REPLY_HEADERS")

        for key, value in headers.items():
            if not isinstance(key, str) or not isinstance(value, str):
                raise InboxContractError(
                    "INVALID_AUTO_REPLY_HEADERS"
                )

            try:
                key.encode("utf-8")
                value.encode("utf-8")
            except UnicodeEncodeError:
                raise InboxContractError(
                    "INVALID_AUTO_REPLY_HEADERS"
                ) from None

    # 14. Calculate deterministic event key
    event_key_data = [
        envelope["provider"],
        binding["mailbox_ref"],
        envelope["provider_message_id"],
    ]

    try:
        event_key_payload = json.dumps(
            event_key_data,
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
    except UnicodeError:
        raise InboxContractError("INVALID_ID") from None

    event_key = hashlib.sha256(
        event_key_payload
    ).hexdigest()

    # 15. Build normalized result
    result = {
        "schema_version": "FIRST_INBOUND_V1",
        "client_id": binding["client_id"],
        "runtime_campaign_id": binding["runtime_campaign_id"],
        "mailbox_ref": binding["mailbox_ref"],
        "provider": envelope["provider"],
        "message_id": envelope["provider_message_id"],
        "thread_id": envelope["provider_thread_id"],
        "sender_email": normalized_sender,
        "recipient_email": normalized_recipient,
        "received_at": received_at_utc,
        "body_text": body,
        "event_kind": event_kind,
        "in_reply_to": in_reply_to,
        "event_key": event_key,
    }

    # 16. Copy optional headers without modifying input
    if "auto_reply_headers" in envelope:
        result["auto_reply_headers"] = (
            envelope["auto_reply_headers"].copy()
        )

    return result
