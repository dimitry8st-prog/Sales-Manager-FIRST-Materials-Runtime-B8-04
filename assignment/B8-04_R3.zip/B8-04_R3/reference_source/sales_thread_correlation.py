r"""FIRST_THREAD_CORRELATION_V1 — exact inbound thread correlation.

Привязка входящего письма (событие ``FIRST_INBOUND_V1`` от принятого нормализатора F1-02)
к известному лиду по **точным** техническим основаниям: совпадению ``thread_id`` или
``in_reply_to`` со списком наших исходящих сообщений ``outbound_message_ids``.

Модуль — чистая функция: без сети, БД, файлов, часов, случайности и окружения. Входы не
изменяются, порядок ``records`` не влияет на решение. Время передаётся явно (в самом
событии), повторная проверка времени/лимита тела и вычисление ``event_key`` НЕ выполняются —
это обязанность принятого нормализатора F1-02.

Границы доверия
---------------
* Аутентификацию провайдера делает доверенный адаптер ВНЕ этого модуля. Ни одно поле
  события (включая ``event_key``) не даёт доверенности и не используется для выбора лида.
* ``body_text``, ``received_at``, ``auto_reply_headers`` и язык — неинтерпретируемые данные,
  в выборе лида не участвуют. Модуль не переводит и не классифицирует текст.
* ``automation_allowed=True`` — это **признак текущего владельца** (ownership=AUTOMATION),
  а НЕ разрешение отправки. Права, стопы, квоты и гранты проверяются отдельно
  непосредственно перед действием.
* Модуль ничего не хранит. Даже ``QUARANTINE`` не означает удаление: сохранение входящего
  доказательства — обязанность вызывающего интегратора.

Структурные ошибки (порядок проверки фиксирован)
------------------------------------------------
``INVALID_EVENT`` → ``INVALID_SCOPE`` → ``INVALID_RECORDS``, все три структуры проверяются
ДО любого бизнес-решения. Наружу не выпускаются сырые ``KeyError``/``TypeError``.

Коды бизнес-результата: ``SCOPE_MISMATCH``, ``EVENT_KIND_NOT_SUPPORTED``,
``UNKNOWN_THREAD``, ``SENDER_MISMATCH``, ``AMBIGUOUS_BINDING``, ``EXACT_BINDING``.

Замороженная схема синтетических fixtures (только test-данные, не live-настройки)
---------------------------------------------------------------------------------
scope  ``FIRST_CORRELATION_SCOPE_V1``: schema_version, client_id, runtime_campaign_id
       (канонический UUID), mailbox_ref, provider, recipient_email (нормализованный адрес
       нашего ящика). Ровно эти поля, лишние запрещены.
event  ``FIRST_INBOUND_V1``: schema_version, client_id, runtime_campaign_id, mailbox_ref,
       provider, message_id, thread_id, sender_email, recipient_email, received_at,
       body_text, event_kind (INBOUND_MESSAGE|DELIVERY_FAILURE), in_reply_to (null|ID),
       event_key (64 lowercase hex). Допустимо единственное дополнительное поле
       ``auto_reply_headers`` (dict str→str).
record: client_id, runtime_campaign_id, mailbox_ref, provider, lead_id, thread_id,
       sender_email, outbound_message_ids (0..100 уникальных ID), ownership
       (AUTOMATION|HUMAN|STOPPED).

ID: непустая строка, ``value == value.strip()``, без ASCII-управляющих U+0000..U+001F/U+007F.
Лимит 256 символов применяется только к ID новых scope/records; для ID нормализованного
события дополнительный максимум не вводится (не зафиксирован контрактом F1-02).
Email в новых scope/records и в нормализованном событии должен быть уже нормализован:
``value == value.strip().casefold()`` и соответствовать ``[^\s@]+@[^\s@]+\.[^\s@]+``.
Регистр самостоятельно не исправляется. Это проверка формы, а не доказательство владения.

Выход ``FIRST_THREAD_CORRELATION_V1`` — всегда ровно 13 ключей, тело письма, адреса,
реестр кандидатов и сведения чужого scope не включаются.
"""

from __future__ import annotations

import re
import uuid

__all__ = ["ThreadCorrelationError", "correlate_inbound"]

# --- schema / enum markers ---------------------------------------------------

SCHEMA_EVENT = "FIRST_INBOUND_V1"
SCHEMA_SCOPE = "FIRST_CORRELATION_SCOPE_V1"
SCHEMA_OUT = "FIRST_THREAD_CORRELATION_V1"

EVENT_KIND_INBOUND = "INBOUND_MESSAGE"
EVENT_KIND_DELIVERY_FAILURE = "DELIVERY_FAILURE"

STATUS_MATCHED = "MATCHED"
STATUS_QUARANTINE = "QUARANTINE"

REASON_SCOPE_MISMATCH = "SCOPE_MISMATCH"
REASON_EVENT_KIND_NOT_SUPPORTED = "EVENT_KIND_NOT_SUPPORTED"
REASON_UNKNOWN_THREAD = "UNKNOWN_THREAD"
REASON_SENDER_MISMATCH = "SENDER_MISMATCH"
REASON_AMBIGUOUS_BINDING = "AMBIGUOUS_BINDING"
REASON_EXACT_BINDING = "EXACT_BINDING"

MATCHED_BY_THREAD = "THREAD"
MATCHED_BY_IN_REPLY_TO = "IN_REPLY_TO"
MATCHED_BY_BOTH = "BOTH"

ERROR_INVALID_EVENT = "INVALID_EVENT"
ERROR_INVALID_SCOPE = "INVALID_SCOPE"
ERROR_INVALID_RECORDS = "INVALID_RECORDS"

OWNERSHIP_AUTOMATION = "AUTOMATION"
OWNERSHIP_HUMAN = "HUMAN"
OWNERSHIP_STOPPED = "STOPPED"

# Поля, по которым событие обязано совпасть со scope (шаг 2 алгоритма).
_SCOPE_MATCH_FIELDS = ("client_id", "runtime_campaign_id", "mailbox_ref", "provider", "recipient_email")
# Поля области данных, по которым record обязан совпасть со scope (шаг 4).
_RECORD_SCOPE_FIELDS = ("client_id", "runtime_campaign_id", "mailbox_ref", "provider")

_EVENT_REQUIRED_KEYS = frozenset(
    {
        "schema_version",
        "client_id",
        "runtime_campaign_id",
        "mailbox_ref",
        "provider",
        "message_id",
        "thread_id",
        "sender_email",
        "recipient_email",
        "received_at",
        "body_text",
        "event_kind",
        "in_reply_to",
        "event_key",
    }
)
_EVENT_OPTIONAL_KEYS = frozenset({"auto_reply_headers"})
_EVENT_KINDS = frozenset({EVENT_KIND_INBOUND, EVENT_KIND_DELIVERY_FAILURE})

_SCOPE_KEYS = frozenset(
    {"schema_version", "client_id", "runtime_campaign_id", "mailbox_ref", "provider", "recipient_email"}
)

_RECORD_KEYS = frozenset(
    {
        "client_id",
        "runtime_campaign_id",
        "mailbox_ref",
        "provider",
        "lead_id",
        "thread_id",
        "sender_email",
        "outbound_message_ids",
        "ownership",
    }
)
_OWNERSHIP_VALUES = frozenset({OWNERSHIP_AUTOMATION, OWNERSHIP_HUMAN, OWNERSHIP_STOPPED})

# Границы размеров (только новые структуры scope/records).
MAX_NEW_ID_CHARS = 256
MAX_RECORDS = 1000
MAX_OUTBOUND_IDS = 100

_CONTROL_CHARS = re.compile(r"[\x00-\x1f\x7f]")
_EMAIL_RE = re.compile(r"[^\s@]+@[^\s@]+\.[^\s@]+")
_EVENT_KEY_RE = re.compile(r"[0-9a-f]{64}")


class ThreadCorrelationError(ValueError):
    """Структурная ошибка входа. ``code`` — стабильный код, ``str(exc) == code``.

    Сообщение содержит только код: без email, тела письма и исходных объектов.
    """

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)

    def __str__(self) -> str:  # noqa: D105 - намеренно только код
        return self.code


# --- примитивные проверки ----------------------------------------------------


def _is_id(value: object, *, max_len: int | None = None) -> bool:
    """ID: строгая непустая str без крайних пробелов и ASCII-управляющих символов."""
    if type(value) is not str:
        return False
    if value == "":
        return False
    if value != value.strip():
        return False
    if _CONTROL_CHARS.search(value):
        return False
    if max_len is not None and len(value) > max_len:
        return False
    return True


def _is_canonical_uuid(value: object) -> bool:
    """``runtime_campaign_id``: канонический UUID, ``str(uuid.UUID(value)) == value``."""
    if not _is_id(value):
        return False
    try:
        return str(uuid.UUID(value)) == value
    except (ValueError, AttributeError, TypeError):
        return False


def _is_normalized_email(value: object) -> bool:
    """Уже нормализованный адрес: ``value == value.strip().casefold()`` и форма email."""
    if type(value) is not str:
        return False
    if value == "":
        return False
    if value != value.strip().casefold():
        return False
    return _EMAIL_RE.fullmatch(value) is not None


def _is_nonempty_str(value: object) -> bool:
    return type(value) is str and value != ""


# --- валидация структур (выполняется до бизнес-решения) ----------------------


def _validate_event(event: object) -> None:
    if type(event) is not dict:
        raise ThreadCorrelationError(ERROR_INVALID_EVENT)
    keys = set(event.keys())
    if not _EVENT_REQUIRED_KEYS <= keys:
        raise ThreadCorrelationError(ERROR_INVALID_EVENT)
    if not keys <= (_EVENT_REQUIRED_KEYS | _EVENT_OPTIONAL_KEYS):
        raise ThreadCorrelationError(ERROR_INVALID_EVENT)
    # Точный встроенный str: подкласс str с верным значением не принимается, а объект
    # с бросающим __ne__ не выпускает наружу постороннее исключение (§4 «точные встроенные типы»).
    if type(event["schema_version"]) is not str or event["schema_version"] != SCHEMA_EVENT:
        raise ThreadCorrelationError(ERROR_INVALID_EVENT)
    # ID события: без дополнительного лимита длины.
    for field in ("client_id", "mailbox_ref", "provider", "message_id", "thread_id"):
        if not _is_id(event[field]):
            raise ThreadCorrelationError(ERROR_INVALID_EVENT)
    if not _is_canonical_uuid(event["runtime_campaign_id"]):
        raise ThreadCorrelationError(ERROR_INVALID_EVENT)
    if not _is_normalized_email(event["sender_email"]):
        raise ThreadCorrelationError(ERROR_INVALID_EVENT)
    if not _is_normalized_email(event["recipient_email"]):
        raise ThreadCorrelationError(ERROR_INVALID_EVENT)
    if not _is_nonempty_str(event["received_at"]):
        raise ThreadCorrelationError(ERROR_INVALID_EVENT)
    if not _is_nonempty_str(event["body_text"]):
        raise ThreadCorrelationError(ERROR_INVALID_EVENT)
    # Проверка типа обязательна ДО проверки вхождения: нехешируемое значение
    # (list/dict) иначе выбросит TypeError наружу, что контракт запрещает.
    if type(event["event_kind"]) is not str or event["event_kind"] not in _EVENT_KINDS:
        raise ThreadCorrelationError(ERROR_INVALID_EVENT)
    in_reply_to = event["in_reply_to"]
    if in_reply_to is not None and not _is_id(in_reply_to):
        raise ThreadCorrelationError(ERROR_INVALID_EVENT)
    event_key = event["event_key"]
    if type(event_key) is not str or _EVENT_KEY_RE.fullmatch(event_key) is None:
        raise ThreadCorrelationError(ERROR_INVALID_EVENT)
    if "auto_reply_headers" in event:
        headers = event["auto_reply_headers"]
        if type(headers) is not dict:
            raise ThreadCorrelationError(ERROR_INVALID_EVENT)
        for header_key, header_value in headers.items():
            if type(header_key) is not str or type(header_value) is not str:
                raise ThreadCorrelationError(ERROR_INVALID_EVENT)


def _validate_scope(scope: object) -> None:
    if type(scope) is not dict or set(scope.keys()) != _SCOPE_KEYS:
        raise ThreadCorrelationError(ERROR_INVALID_SCOPE)
    if type(scope["schema_version"]) is not str or scope["schema_version"] != SCHEMA_SCOPE:
        raise ThreadCorrelationError(ERROR_INVALID_SCOPE)
    if not _is_id(scope["client_id"], max_len=MAX_NEW_ID_CHARS):
        raise ThreadCorrelationError(ERROR_INVALID_SCOPE)
    if not _is_canonical_uuid(scope["runtime_campaign_id"]):
        raise ThreadCorrelationError(ERROR_INVALID_SCOPE)
    if not _is_id(scope["mailbox_ref"], max_len=MAX_NEW_ID_CHARS):
        raise ThreadCorrelationError(ERROR_INVALID_SCOPE)
    if not _is_id(scope["provider"], max_len=MAX_NEW_ID_CHARS):
        raise ThreadCorrelationError(ERROR_INVALID_SCOPE)
    if not _is_normalized_email(scope["recipient_email"]):
        raise ThreadCorrelationError(ERROR_INVALID_SCOPE)


def _validate_records(records: object) -> None:
    if type(records) is not list or len(records) > MAX_RECORDS:
        raise ThreadCorrelationError(ERROR_INVALID_RECORDS)
    for record in records:
        if type(record) is not dict or set(record.keys()) != _RECORD_KEYS:
            raise ThreadCorrelationError(ERROR_INVALID_RECORDS)
        if not _is_id(record["client_id"], max_len=MAX_NEW_ID_CHARS):
            raise ThreadCorrelationError(ERROR_INVALID_RECORDS)
        if not _is_canonical_uuid(record["runtime_campaign_id"]):
            raise ThreadCorrelationError(ERROR_INVALID_RECORDS)
        if not _is_id(record["mailbox_ref"], max_len=MAX_NEW_ID_CHARS):
            raise ThreadCorrelationError(ERROR_INVALID_RECORDS)
        if not _is_id(record["provider"], max_len=MAX_NEW_ID_CHARS):
            raise ThreadCorrelationError(ERROR_INVALID_RECORDS)
        if not _is_id(record["lead_id"], max_len=MAX_NEW_ID_CHARS):
            raise ThreadCorrelationError(ERROR_INVALID_RECORDS)
        if not _is_id(record["thread_id"], max_len=MAX_NEW_ID_CHARS):
            raise ThreadCorrelationError(ERROR_INVALID_RECORDS)
        if not _is_normalized_email(record["sender_email"]):
            raise ThreadCorrelationError(ERROR_INVALID_RECORDS)
        outbound = record["outbound_message_ids"]
        if type(outbound) is not list or len(outbound) > MAX_OUTBOUND_IDS:
            raise ThreadCorrelationError(ERROR_INVALID_RECORDS)
        seen: set[str] = set()
        for message_id in outbound:
            if not _is_id(message_id, max_len=MAX_NEW_ID_CHARS):
                raise ThreadCorrelationError(ERROR_INVALID_RECORDS)
            if message_id in seen:  # повтор одинакового ID внутри записи — ошибка структуры
                raise ThreadCorrelationError(ERROR_INVALID_RECORDS)
            seen.add(message_id)
        # Тип проверяется до вхождения по той же причине, что и event_kind выше.
        if type(record["ownership"]) is not str or record["ownership"] not in _OWNERSHIP_VALUES:
            raise ThreadCorrelationError(ERROR_INVALID_RECORDS)


# --- результат ---------------------------------------------------------------


def _base_result(event: dict, scope: dict) -> dict:
    # Порядок ключей фиксирован контрактом §7.
    return {
        "schema_version": SCHEMA_OUT,
        "event_key": event["event_key"],
        "message_id": event["message_id"],
        "client_id": scope["client_id"],
        "runtime_campaign_id": scope["runtime_campaign_id"],
        "mailbox_ref": scope["mailbox_ref"],
        "provider": scope["provider"],
        "status": STATUS_QUARANTINE,
        "reason": None,
        "lead_id": None,
        "ownership": None,
        "matched_by": None,
        "automation_allowed": False,
    }


def _quarantine(result: dict, reason: str) -> dict:
    result["status"] = STATUS_QUARANTINE
    result["reason"] = reason
    result["lead_id"] = None
    result["ownership"] = None
    result["matched_by"] = None
    result["automation_allowed"] = False
    return result


def _decide(event: dict, scope: dict, records: list) -> dict:
    result = _base_result(event, scope)

    # Шаг 2. Совпадение события со scope; несовпадение — карантин без сведений о лидах.
    for field in _SCOPE_MATCH_FIELDS:
        if event[field] != scope[field]:
            return _quarantine(result, REASON_SCOPE_MISMATCH)

    # Шаг 3. Отбой/служебное — не покупатель.
    if event["event_kind"] == EVENT_KIND_DELIVERY_FAILURE:
        return _quarantine(result, REASON_EVENT_KIND_NOT_SUPPORTED)

    # Шаг 4. Только записи строго нашей области данных; чужие корректные игнорируются.
    in_scope = [
        record
        for record in records
        if all(record[field] == scope[field] for field in _RECORD_SCOPE_FIELDS)
    ]

    # Шаг 5. Кандидаты — объединение совпадений по thread_id и по in_reply_to.
    thread_id = event["thread_id"]
    in_reply_to = event["in_reply_to"]
    thread_ground = False
    reply_ground = False
    candidates = []
    for record in in_scope:
        by_thread = record["thread_id"] == thread_id
        by_reply = in_reply_to is not None and in_reply_to in record["outbound_message_ids"]
        if by_thread or by_reply:
            candidates.append(record)
            thread_ground = thread_ground or by_thread
            reply_ground = reply_ground or by_reply
    if not candidates:
        return _quarantine(result, REASON_UNKNOWN_THREAD)

    # Шаг 6. sender обязан совпасть у ВСЕХ кандидатов; совпадения одного среди
    # противоречивых записей недостаточно.
    sender_email = event["sender_email"]
    for record in candidates:
        if record["sender_email"] != sender_email:
            return _quarantine(result, REASON_SENDER_MISMATCH)

    # Шаг 7. Множество пар (lead_id, ownership). Идентичные дубли и разный порядок
    # outbound_message_ids пару не меняют; противоречивое ownership одного лида — меняет.
    pairs = {(record["lead_id"], record["ownership"]) for record in candidates}
    if len(pairs) > 1:
        return _quarantine(result, REASON_AMBIGUOUS_BINDING)

    # Шаг 8. Одна согласованная пара.
    lead_id, ownership = next(iter(pairs))
    if thread_ground and reply_ground:
        matched_by = MATCHED_BY_BOTH
    elif thread_ground:
        matched_by = MATCHED_BY_THREAD
    else:
        matched_by = MATCHED_BY_IN_REPLY_TO
    result["status"] = STATUS_MATCHED
    result["reason"] = REASON_EXACT_BINDING
    result["lead_id"] = lead_id
    result["ownership"] = ownership
    result["matched_by"] = matched_by
    # Владелец = AUTOMATION, но это только признак, НЕ разрешение отправки.
    result["automation_allowed"] = ownership == OWNERSHIP_AUTOMATION
    return result


def correlate_inbound(event: dict, *, scope: dict, records: list) -> dict:
    """Точно привязать входящее письмо к лиду.

    ``event`` — нормализованное событие ``FIRST_INBOUND_V1`` (F1-02);
    ``scope`` — ожидаемая область данных ``FIRST_CORRELATION_SCOPE_V1``;
    ``records`` — реестр известных переписок (0..1000 записей).

    Возвращает ``FIRST_THREAD_CORRELATION_V1`` (13 ключей) со ``status`` MATCHED/QUARANTINE
    и одним из reason-кодов. Структурные ошибки: :class:`ThreadCorrelationError` с ``code``
    ``INVALID_EVENT`` → ``INVALID_SCOPE`` → ``INVALID_RECORDS`` (проверяются в этом порядке
    до бизнес-решения). Чистая функция: входы не изменяются, порядок ``records`` не влияет
    на результат, побочных эффектов и обращения к окружению нет.
    """
    _validate_event(event)
    _validate_scope(scope)
    _validate_records(records)
    return _decide(event, scope, records)
