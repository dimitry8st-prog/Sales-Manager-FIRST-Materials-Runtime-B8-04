"""Pure validation and projection for an F1-24 operational quarantine ticket."""

from __future__ import annotations

import hashlib
import json
import re
import uuid
from datetime import datetime, timedelta


_INPUT_SCHEMA = "FIRST_QUARANTINE_TICKET_INPUT_V1"
_OUTPUT_SCHEMA = "FIRST_QUARANTINE_TICKET_V1"
_ROOT_KEYS = frozenset(
    {
        "schema_version",
        "scope",
        "event_key",
        "category",
        "evidence_ref",
        "occurred_at",
        "diagnostic",
    }
)
_SCOPE_KEYS = frozenset({"client_id", "runtime_campaign_id", "mailbox_ref"})
_DIAGNOSTIC_KEYS = frozenset(
    {"body_text", "sender_email", "subject", "provider_error"}
)
_CATEGORIES = frozenset(
    {
        "UNMATCHED_THREAD",
        "AMBIGUOUS_THREAD",
        "HUMAN_OWNED",
        "STOPPED",
        "CORRELATION_FAILURE",
        "OVERSIZE_CONTEXT",
    }
)
_INFO_CATEGORIES = frozenset({"HUMAN_OWNED", "STOPPED"})
_WARNING_CATEGORIES = frozenset({"UNMATCHED_THREAD", "AMBIGUOUS_THREAD"})
_HEX_EVENT_KEY = re.compile(r"[0-9a-f]{64}\Z")


class QuarantineTicketError(ValueError):
    """Validation error whose public code never exposes rejected input."""

    __slots__ = ("__code",)

    def __init__(self, code: str) -> None:
        object.__setattr__(self, "_QuarantineTicketError__code", code)
        ValueError.__init__(self, code)

    @property
    def code(self) -> str:
        """Read-only stable machine-readable error code."""
        return self.__code

    def __setattr__(self, name: str, value: object) -> None:
        if name == "code":
            raise AttributeError("code is read-only")
        object.__setattr__(self, name, value)


def _fail(code: str) -> None:
    raise QuarantineTicketError(code)


def _valid_unicode(value: str) -> bool:
    """Return whether text can be encoded as UTF-8 without surrogate code points."""
    try:
        value.encode("utf-8")
    except UnicodeEncodeError:
        return False
    return True


def _valid_identifier(value: object) -> bool:
    if type(value) is not str or not _valid_unicode(value):
        return False
    try:
        byte_length = len(value.encode("utf-8"))
    except UnicodeEncodeError:
        return False
    if not 1 <= byte_length <= 128:
        return False
    for character in value:
        codepoint = ord(character)
        if character.isspace() or codepoint <= 0x1F or codepoint == 0x7F:
            return False
    return True


def _has_exact_keys(value: dict, expected: frozenset[str]) -> bool:
    return all(type(key) is str for key in value) and value.keys() == expected


def _valid_scope(value: object) -> bool:
    if type(value) is not dict or not _has_exact_keys(value, _SCOPE_KEYS):
        return False
    if not _valid_identifier(value["client_id"]):
        return False
    if not _valid_identifier(value["mailbox_ref"]):
        return False
    campaign_id = value["runtime_campaign_id"]
    if not _valid_identifier(campaign_id):
        return False
    try:
        if str(uuid.UUID(campaign_id)) != campaign_id:
            return False
    except (ValueError, AttributeError, TypeError, OverflowError):
        return False
    return True


def _valid_diagnostic(value: object) -> bool:
    if type(value) is not dict or not _has_exact_keys(value, _DIAGNOSTIC_KEYS):
        return False
    for item in value.values():
        if item is None:
            continue
        if type(item) is not str or not _valid_unicode(item):
            return False
        try:
            if len(item.encode("utf-8")) > 65536:
                return False
        except UnicodeEncodeError:
            return False
    return True


def _valid_timestamp(value: object) -> bool:
    if type(value) is not str or not value.endswith("+00:00"):
        return False
    try:
        parsed = datetime.fromisoformat(value)
        return (
            parsed.utcoffset() == timedelta(0)
            and parsed.isoformat() == value
            and value.endswith("+00:00")
        )
    except (ValueError, OverflowError, TypeError):
        return False


def build_quarantine_ticket(snapshot: dict) -> dict:
    """Validate ``snapshot`` and return its minimal, deterministic ticket view.

    Validation failures follow the exact priority from CONTRACT.md. No input is
    mutated and diagnostic data is validated but never copied into the result.
    """
    # 1. Root shape and schema version have the highest priority.
    if type(snapshot) is not dict or not _has_exact_keys(snapshot, _ROOT_KEYS):
        _fail("INVALID_INPUT")
    if (
        type(snapshot["schema_version"]) is not str
        or snapshot["schema_version"] != _INPUT_SCHEMA
    ):
        _fail("INVALID_INPUT")

    # 2. Scope validation.
    if not _valid_scope(snapshot["scope"]):
        _fail("INVALID_SCOPE")

    # 3. Event key.
    event_key = snapshot["event_key"]
    if type(event_key) is not str or _HEX_EVENT_KEY.fullmatch(event_key) is None:
        _fail("INVALID_EVENT_KEY")

    # 4. Category.
    category = snapshot["category"]
    if type(category) is not str or category not in _CATEGORIES:
        _fail("INVALID_CATEGORY")

    # 5. Evidence reference follows the same opaque ID rules as scope IDs.
    if not _valid_identifier(snapshot["evidence_ref"]):
        _fail("INVALID_EVIDENCE_REF")

    # 6. Timestamp must be a canonical datetime.isoformat() UTC string.
    if not _valid_timestamp(snapshot["occurred_at"]):
        _fail("INVALID_TIMESTAMP")

    # 7. Validate diagnostics last; the values are intentionally never emitted.
    if not _valid_diagnostic(snapshot["diagnostic"]):
        _fail("INVALID_DIAGNOSTIC")

    # Scope contains only validated immutable scalar strings. Copying the dict
    # therefore creates an independent deep-equivalent copy with no shared
    # mutable descendants.
    scope_copy = dict(snapshot["scope"])
    key_material = {
        "scope": scope_copy,
        "event_key": event_key,
        "category": category,
    }
    canonical_json = json.dumps(
        key_material,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )
    ticket_key = hashlib.sha256(canonical_json.encode("utf-8")).hexdigest()

    return {
        "schema_version": _OUTPUT_SCHEMA,
        "scope": scope_copy,
        "event_key": event_key,
        "ticket_key": ticket_key,
        "category": category,
        "evidence_ref": snapshot["evidence_ref"],
        "occurred_at": snapshot["occurred_at"],
        "severity": (
            "INFO"
            if category in _INFO_CATEGORIES
            else "WARNING"
            if category in _WARNING_CATEGORIES
            else "ERROR"
        ),
        "automation_allowed": False,
    }
