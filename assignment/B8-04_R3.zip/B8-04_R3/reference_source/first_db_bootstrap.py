"""F1-33: explicit database connection deadlines. Implement CONTRACT.json."""

_POLICY_KEYS = frozenset(
    ("connect_timeout_seconds", "statement_timeout_ms", "lock_timeout_ms")
)
_FORBIDDEN_KWARGS = frozenset(("options", "connect_timeout", "conninfo", "dsn"))


def _invalid():
    return ValueError("INVALID_DB_DEADLINE_INPUT")


def _is_int(value):
    return type(value) is int


def _canonical_keys(value):
    result = {}
    for key, item in value.items():
        if not isinstance(key, str):
            raise _invalid()
        name = str.__str__(key)
        if name in result:
            raise _invalid()
        result[name] = item
    return result


def connect_with_deadlines(connect_factory, connection_kwargs, policy):
    if not callable(connect_factory):
        raise _invalid()
    if type(connection_kwargs) is not dict or type(policy) is not dict:
        raise _invalid()
    canonical_policy = _canonical_keys(policy)
    new_kwargs = _canonical_keys(connection_kwargs)
    if set(canonical_policy) != _POLICY_KEYS:
        raise _invalid()
    if any(key in _FORBIDDEN_KWARGS for key in new_kwargs):
        raise _invalid()
    connect_timeout = canonical_policy["connect_timeout_seconds"]
    statement_timeout = canonical_policy["statement_timeout_ms"]
    lock_timeout = canonical_policy["lock_timeout_ms"]
    if not (
        _is_int(connect_timeout)
        and _is_int(statement_timeout)
        and _is_int(lock_timeout)
    ):
        raise _invalid()
    if not 1 <= connect_timeout <= 60:
        raise _invalid()
    if not 1 <= statement_timeout <= 60000:
        raise _invalid()
    if not 1 <= lock_timeout <= 60000 or lock_timeout > statement_timeout:
        raise _invalid()

    new_kwargs["connect_timeout"] = connect_timeout
    new_kwargs["options"] = (
        f"-c statement_timeout={statement_timeout} -c lock_timeout={lock_timeout}"
    )
    return connect_factory(**new_kwargs)
