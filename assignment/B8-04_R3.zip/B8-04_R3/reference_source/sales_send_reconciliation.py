"""F1-21: conservative reconciliation of send evidence for one attempt.

Pure function. No I/O, no provider calls, no SQL, no journal mutation, no
resend authorization, no clock access. Standard library only.

Public API::

    from sales_send_reconciliation import (
        reconcile_send_evidence,
        ReconciliationError,
    )

Imports the accepted F1-08 normalizer and its error class. Does not copy or
weaken F108 validation. Validation order:

    INVALID_INPUT
    -> INVALID_ATTEMPT
    -> INVALID_CURRENT_RECEIPT
    -> evidence errors in input order
       (INVALID_RECEIPT / RECEIPT_SCOPE_MISMATCH / INCONSISTENT_RECEIPT)

All F108 error codes are preserved inside ReconciliationError.code.
"""

from __future__ import annotations

import copy

from sales_first_send_receipt import (
    SendReceiptError,
    normalize_send_receipt,
)

__all__ = ["reconcile_send_evidence", "ReconciliationError"]


# ---------------------------------------------------------------------------
# Public error
# ---------------------------------------------------------------------------

class ReconciliationError(ValueError):
    """Contract error. str(error) is the code only; input is never included."""

    def __init__(self, code: str) -> None:
        super().__init__(code)
        self._code = code

    @property
    def code(self) -> str:
        return self._code

    def __str__(self) -> str:
        return self._code


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DECISION_SCHEMA = "FIRST_SEND_RECONCILIATION_DECISION_V1"
RECEIPT_SCHEMA = "FIRST_SEND_RECEIPT_V1"
RAW_RECEIPT_SCHEMA = "FIRST_PROVIDER_SEND_RESULT_V1"

# Error codes
INVALID_INPUT = "INVALID_INPUT"
INVALID_ATTEMPT = "INVALID_ATTEMPT"
INVALID_CURRENT_RECEIPT = "INVALID_CURRENT_RECEIPT"
INVALID_RECEIPT = "INVALID_RECEIPT"
RECEIPT_SCOPE_MISMATCH = "RECEIPT_SCOPE_MISMATCH"
INCONSISTENT_RECEIPT = "INCONSISTENT_RECEIPT"

# Statuses
STATUS_UNCHANGED = "UNCHANGED"
STATUS_PROPOSE_UPDATE = "PROPOSE_UPDATE"
STATUS_CONFLICT = "CONFLICT"

# Decision codes
CODE_NO_NEW_CONCLUSIVE_EVIDENCE = "NO_NEW_CONCLUSIVE_EVIDENCE"
CODE_CONSISTENT_PROGRESS = "CONSISTENT_PROGRESS"
CODE_CONTRADICTORY_EVIDENCE = "CONTRADICTORY_EVIDENCE"

# F108 normalized states
STATE_UNKNOWN = "UNKNOWN"
STATE_ACCEPTED = "ACCEPTED"
STATE_DELIVERED = "DELIVERED"
STATE_NOT_SENT = "NOT_SENT"

# F108 normalized reasons
REASON_AMBIGUOUS_TIMEOUT = "AMBIGUOUS_TIMEOUT"
REASON_AMBIGUOUS_RESULT = "AMBIGUOUS_RESULT"
REASON_NO_PROVIDER_EVIDENCE = "NO_PROVIDER_EVIDENCE"
REASON_PROVIDER_ACCEPTED = "PROVIDER_ACCEPTED"
REASON_PROVIDER_DELIVERED = "PROVIDER_DELIVERED"
REASON_KNOWN_NOT_SENT = "KNOWN_NOT_SENT"

# Raw outcome names
OUTCOME_ACCEPTED = "ACCEPTED"
OUTCOME_DELIVERED = "DELIVERED"
OUTCOME_NOT_SENT = "NOT_SENT"
OUTCOME_TIMEOUT = "TIMEOUT"
OUTCOME_UNKNOWN = "UNKNOWN"

# Raw not_sent_reason names, chosen by attempt phase
NOT_SENT_REASON_PREPARED = "NOT_DISPATCHED"
NOT_SENT_REASON_DISPATCH_STARTED = "PROVIDER_REJECTED_BEFORE_ACCEPTANCE"

# Result keys — exact, in fixed order.
_RESULT_KEYS = (
    "schema_version",
    "action_id",
    "attempt_no",
    "payload_sha256",
    "status",
    "code",
    "proposed_receipt",
    "evidence_refs",
    "journal_mutation_required",
    "resend_authorized",
)

# Receipt keys — exact, in fixed order (matches F108 output).
_RECEIPT_KEYS = (
    "schema_version",
    "client_id",
    "runtime_campaign_id",
    "lead_id",
    "mailbox_ref",
    "action_id",
    "attempt_no",
    "payload_sha256",
    "phase",
    "state",
    "reason",
    "provider_message_id",
    "evidence_ref",
    "reconciliation_required",
    "resend_authorized",
)

# Scope fields.
_ID_FIELDS = (
    "client_id",
    "runtime_campaign_id",
    "lead_id",
    "mailbox_ref",
    "action_id",
)

_SCOPE_FIELDS = _ID_FIELDS + ("attempt_no", "payload_sha256")

# Bounds — mirror of F108 contract (same rules, not copied code).
_ID_MAX_LEN = 128
_ATTEMPT_NO_MIN = 1
_ATTEMPT_NO_MAX = 1_000_000
_HASH_LEN = 64
_HEX_LOWER = frozenset("0123456789abcdef")

_PHASES = frozenset(("PREPARED", "DISPATCH_STARTED"))
_STATES = frozenset((STATE_UNKNOWN, STATE_ACCEPTED, STATE_DELIVERED, STATE_NOT_SENT))
_REASONS = frozenset((
    REASON_NO_PROVIDER_EVIDENCE,
    REASON_AMBIGUOUS_TIMEOUT,
    REASON_AMBIGUOUS_RESULT,
    REASON_PROVIDER_ACCEPTED,
    REASON_PROVIDER_DELIVERED,
    REASON_KNOWN_NOT_SENT,
))

# Allowed (state, reason) pairs — must match F108 normalization table.
_STATE_REASON_ALLOWED = {
    STATE_UNKNOWN: frozenset((
        REASON_NO_PROVIDER_EVIDENCE,
        REASON_AMBIGUOUS_TIMEOUT,
        REASON_AMBIGUOUS_RESULT,
    )),
    STATE_ACCEPTED: frozenset((REASON_PROVIDER_ACCEPTED,)),
    STATE_DELIVERED: frozenset((REASON_PROVIDER_DELIVERED,)),
    STATE_NOT_SENT: frozenset((REASON_KNOWN_NOT_SENT,)),
}

_EVIDENCE_CAP = 100


# ---------------------------------------------------------------------------
# Strict canonical equality
# ---------------------------------------------------------------------------

def _canonical_equal(a, b) -> bool:
    """Builtin-type aware recursive equality.

    Python 0 == False is True, but here they are not equal. Dict keysets and
    list lengths must match exactly.
    """
    if type(a) is not type(b):
        return False
    if isinstance(a, dict):
        if a.keys() != b.keys():
            return False
        return all(_canonical_equal(a[k], b[k]) for k in a)
    if isinstance(a, list):
        if len(a) != len(b):
            return False
        return all(_canonical_equal(x, y) for x, y in zip(a, b))
    if isinstance(a, float):
        return a == b and (a == a)
    return a == b


# ---------------------------------------------------------------------------
# Field-level validators (mirror F108 contract)
# ---------------------------------------------------------------------------

def _is_id(value) -> bool:
    """id contract: builtin str, len 1..128, no trim, no C0/DEL."""
    if type(value) is not str:
        return False
    if not 1 <= len(value) <= _ID_MAX_LEN:
        return False
    if value != value.strip():
        return False
    return not any(ord(ch) < 0x20 or ord(ch) == 0x7F for ch in value)


def _is_optional_id(value) -> bool:
    return value is None or _is_id(value)


def _is_attempt_no(value) -> bool:
    return type(value) is int and _ATTEMPT_NO_MIN <= value <= _ATTEMPT_NO_MAX


def _is_sha256(value) -> bool:
    return (
        type(value) is str
        and len(value) == _HASH_LEN
        and all(ch in _HEX_LOWER for ch in value)
    )


# ---------------------------------------------------------------------------
# Root validation
# ---------------------------------------------------------------------------

def _validate_root(attempt, current_receipt, evidence) -> None:
    if type(attempt) is not dict:
        raise ReconciliationError(INVALID_INPUT)
    if current_receipt is not None and type(current_receipt) is not dict:
        raise ReconciliationError(INVALID_INPUT)
    if type(evidence) is not list:
        raise ReconciliationError(INVALID_INPUT)
    if len(evidence) > _EVIDENCE_CAP:
        raise ReconciliationError(INVALID_INPUT)


# ---------------------------------------------------------------------------
# Attempt validation via real F108
# ---------------------------------------------------------------------------

def _normalize_attempt(attempt: dict) -> dict:
    try:
        baseline = normalize_send_receipt(attempt, None)
    except SendReceiptError as exc:
        raise ReconciliationError(INVALID_ATTEMPT) from exc
    return baseline


# ---------------------------------------------------------------------------
# Current receipt validation — full structural pass BEFORE reconstruction
# ---------------------------------------------------------------------------

def _validate_current_structure(current) -> None:
    """Validate current_receipt fully, before any dict operation.

    Any deviation maps to INVALID_CURRENT_RECEIPT. This runs BEFORE
    _reconstruct_raw_from_current, so an unhashable `phase` (list/dict)
    cannot reach any dict.get() lookup.
    """
    if type(current) is not dict:
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)

    if set(current.keys()) != set(_RECEIPT_KEYS):
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)
    if len(current) != len(_RECEIPT_KEYS):
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)

    # schema_version
    sv = current["schema_version"]
    if type(sv) is not str or sv != RECEIPT_SCHEMA:
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)

    # scope fields
    for name in _ID_FIELDS:
        if not _is_id(current[name]):
            raise ReconciliationError(INVALID_CURRENT_RECEIPT)
    if not _is_attempt_no(current["attempt_no"]):
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)
    if not _is_sha256(current["payload_sha256"]):
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)

    # phase — str and in known set
    phase = current["phase"]
    if type(phase) is not str:
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)
    if phase not in _PHASES:
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)

    # state — str and in known set
    state = current["state"]
    if type(state) is not str:
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)
    if state not in _STATES:
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)

    # reason — str and in known set
    reason = current["reason"]
    if type(reason) is not str:
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)
    if reason not in _REASONS:
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)

    # state <-> reason compatibility (mirror of F108)
    if reason not in _STATE_REASON_ALLOWED.get(state, frozenset()):
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)

    # provider_message_id / evidence_ref — None or id
    msg = current["provider_message_id"]
    ref = current["evidence_ref"]
    if not _is_optional_id(msg):
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)
    if not _is_optional_id(ref):
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)

    # bool flags — strictly bool
    if type(current["reconciliation_required"]) is not bool:
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)
    if type(current["resend_authorized"]) is not bool:
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)

    # state-specific consistency (mirror of F108 _receipt_consistent)
    if state in (STATE_ACCEPTED, STATE_DELIVERED):
        if phase != "DISPATCH_STARTED":
            raise ReconciliationError(INVALID_CURRENT_RECEIPT)
        if msg is None or ref is None:
            raise ReconciliationError(INVALID_CURRENT_RECEIPT)
    elif state == STATE_NOT_SENT:
        if msg is not None:
            raise ReconciliationError(INVALID_CURRENT_RECEIPT)
        if ref is None:
            raise ReconciliationError(INVALID_CURRENT_RECEIPT)
    elif state == STATE_UNKNOWN:
        if msg is not None or ref is not None:
            raise ReconciliationError(INVALID_CURRENT_RECEIPT)


# ---------------------------------------------------------------------------
# Raw envelope reconstruction from current receipt
# ---------------------------------------------------------------------------

def _reconstruct_raw_from_current(current: dict, attempt: dict):
    """Rebuild the raw FIRST_PROVIDER_SEND_RESULT_V1 envelope for F108.

    Returns the raw dict, or None when F108(attempt, None) is the canonical
    baseline (NO_PROVIDER_EVIDENCE with no message/ref).

    Assumes _validate_current_structure already passed, so phase/state/reason
    are validated strings. No dict.get() on unvalidated keys is performed.
    """
    state = current["state"]
    phase = current["phase"]

    scope = {
        "client_id": current["client_id"],
        "runtime_campaign_id": current["runtime_campaign_id"],
        "lead_id": current["lead_id"],
        "mailbox_ref": current["mailbox_ref"],
        "action_id": current["action_id"],
        "attempt_no": current["attempt_no"],
        "payload_sha256": current["payload_sha256"],
    }

    raw = {
        "schema_version": RAW_RECEIPT_SCHEMA,
        **scope,
        "outcome": None,
        "provider_message_id": current["provider_message_id"],
        "evidence_ref": current["evidence_ref"],
        "not_sent_reason": None,
    }

    if state in (STATE_ACCEPTED, STATE_DELIVERED):
        raw["outcome"] = state
        raw["provider_message_id"] = current["provider_message_id"]
        raw["evidence_ref"] = current["evidence_ref"]
        raw["not_sent_reason"] = None

    elif state == STATE_NOT_SENT:
        # phase already validated as one of _PHASES.
        if phase == "PREPARED":
            raw_reason = NOT_SENT_REASON_PREPARED
        elif phase == "DISPATCH_STARTED":
            raw_reason = NOT_SENT_REASON_DISPATCH_STARTED
        else:
            # unreachable after validation; F108 will reject if reached.
            raw_reason = None
        raw["outcome"] = OUTCOME_NOT_SENT
        raw["provider_message_id"] = None
        raw["evidence_ref"] = current["evidence_ref"]
        raw["not_sent_reason"] = raw_reason

    elif state == STATE_UNKNOWN:
        current_reason = current["reason"]
        if current_reason == REASON_AMBIGUOUS_TIMEOUT:
            raw["outcome"] = OUTCOME_TIMEOUT
        elif current_reason == REASON_AMBIGUOUS_RESULT:
            raw["outcome"] = OUTCOME_UNKNOWN
        elif current_reason == REASON_NO_PROVIDER_EVIDENCE:
            # Canonical baseline: F108(attempt, None) must reproduce current.
            return None
        else:
            # unreachable after validation
            raw["outcome"] = "__RECONSTRUCTION_INVALID__"

    else:
        # unreachable after validation
        raw["outcome"] = "__RECONSTRUCTION_INVALID__"

    return raw


def _validate_current(current: dict, attempt: dict) -> dict:
    """Reconstruct raw envelope, renormalize via F108, require exact equality.

    Any deviation maps to INVALID_CURRENT_RECEIPT. F108 exceptions are
    propagated as INVALID_CURRENT_RECEIPT; unrelated exceptions (TypeError,
    AttributeError, etc.) are NOT masked.
    """
    # 1. Full structural validation first — blocks unhashable phase etc.
    _validate_current_structure(current)

    # 2. Reconstruct raw.
    raw = _reconstruct_raw_from_current(current, attempt)

    # 3. Renormalize via F108 with the authoritative attempt.
    try:
        normalized = normalize_send_receipt(attempt, raw)
    except SendReceiptError as exc:
        raise ReconciliationError(INVALID_CURRENT_RECEIPT) from exc

    # 4. Exact keyset + canonical equality on all 15 fields.
    if set(normalized.keys()) != set(_RECEIPT_KEYS):
        raise ReconciliationError(INVALID_CURRENT_RECEIPT)

    for key in _RECEIPT_KEYS:
        if not _canonical_equal(current[key], normalized[key]):
            raise ReconciliationError(INVALID_CURRENT_RECEIPT)

    return copy.deepcopy(normalized)


# ---------------------------------------------------------------------------
# Evidence validation
# ---------------------------------------------------------------------------

def _normalize_evidence(envelope, attempt: dict) -> dict:
    """Validate one raw evidence envelope via F108; preserve F108 error code."""
    try:
        normalized = normalize_send_receipt(attempt, envelope)
    except SendReceiptError as exc:
        code = getattr(exc, "code", None)
        if code not in (
            INVALID_RECEIPT,
            RECEIPT_SCOPE_MISMATCH,
            INCONSISTENT_RECEIPT,
            INVALID_ATTEMPT,
        ):
            code = INVALID_RECEIPT
        if code == INVALID_ATTEMPT:
            # Attempt was already validated in step 2; per contract map to
            # INVALID_RECEIPT for evidence.
            code = INVALID_RECEIPT
        raise ReconciliationError(code) from exc
    return normalized


# ---------------------------------------------------------------------------
# Candidate selection helpers
# ---------------------------------------------------------------------------

def _is_conclusive(state: str) -> bool:
    return state in (STATE_ACCEPTED, STATE_DELIVERED, STATE_NOT_SENT)


def _state_rank(state: str) -> int:
    if state == STATE_DELIVERED:
        return 3
    if state == STATE_ACCEPTED:
        return 2
    if state == STATE_NOT_SENT:
        return 1
    return 0


def _collect_evidence_refs(current, normalized_evidence) -> list:
    refs = set()
    if current is not None:
        ref = current.get("evidence_ref")
        if type(ref) is str:
            refs.add(ref)
    for receipt in normalized_evidence:
        ref = receipt.get("evidence_ref")
        if type(ref) is str:
            refs.add(ref)
    return sorted(refs)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def reconcile_send_evidence(
    attempt: dict,
    current_receipt,
    evidence: list,
) -> dict:
    """Conservative reconciliation decision for a single send attempt.

    Returns a dict with exactly 10 keys (see _RESULT_KEYS). Raises
    ReconciliationError on any validation failure. Never mutates inputs;
    never authorizes resend; never performs I/O.
    """
    # 1. Root types + cap
    _validate_root(attempt, current_receipt, evidence)

    # 2. Attempt through real F108
    _normalize_attempt(attempt)

    # 3. Current receipt structural validation + reconstruction + equality
    current_normalized = None
    if current_receipt is not None:
        current_normalized = _validate_current(current_receipt, attempt)

    # 4. Evidence in input order — no silent discard
    normalized_evidence = []
    for envelope in evidence:
        if type(envelope) is not dict:
            raise ReconciliationError(INVALID_RECEIPT)
        normalized_evidence.append(_normalize_evidence(envelope, attempt))

    # 5. Candidate set
    candidates = []
    if current_normalized is not None:
        candidates.append(current_normalized)
    candidates.extend(normalized_evidence)

    conclusive = [c for c in candidates if _is_conclusive(c["state"])]

    # 6. Conflict detection
    conflict = False

    delivered_accepted = [
        c for c in conclusive if c["state"] in (STATE_ACCEPTED, STATE_DELIVERED)
    ]
    message_ids = {c["provider_message_id"] for c in delivered_accepted}
    if len(message_ids) > 1:
        conflict = True

    not_sent = [c for c in conclusive if c["state"] == STATE_NOT_SENT]
    if not_sent and delivered_accepted:
        conflict = True

    evidence_refs = _collect_evidence_refs(current_normalized, normalized_evidence)

    if conflict:
        return _make_result(
            attempt=attempt,
            status=STATUS_CONFLICT,
            code=CODE_CONTRADICTORY_EVIDENCE,
            proposed_receipt=None,
            evidence_refs=evidence_refs,
        )

    # 7. No conclusive candidates
    if not conclusive:
        if current_normalized is not None:
            proposed = copy.deepcopy(current_normalized)
        else:
            proposed = normalize_send_receipt(attempt, None)
        return _make_result(
            attempt=attempt,
            status=STATUS_UNCHANGED,
            code=CODE_NO_NEW_CONCLUSIVE_EVIDENCE,
            proposed_receipt=proposed,
            evidence_refs=evidence_refs,
        )

    # 8. Select highest state
    best_rank = max(_state_rank(c["state"]) for c in conclusive)
    top = [c for c in conclusive if _state_rank(c["state"]) == best_rank]

    if len(top) == 1:
        selected = top[0]
    else:
        def ref_key(c):
            ref = c.get("evidence_ref")
            return (ref is None, ref if type(ref) is str else "")
        selected = min(top, key=ref_key)

    # 9. Current anchor
    if current_normalized is not None and _is_conclusive(current_normalized["state"]):
        same_state = current_normalized["state"] == selected["state"]
        same_message = (
            current_normalized["provider_message_id"]
            == selected["provider_message_id"]
        )
        if same_state and same_message:
            return _make_result(
                attempt=attempt,
                status=STATUS_UNCHANGED,
                code=CODE_NO_NEW_CONCLUSIVE_EVIDENCE,
                proposed_receipt=copy.deepcopy(current_normalized),
                evidence_refs=evidence_refs,
            )

    # 10. Propose update
    return _make_result(
        attempt=attempt,
        status=STATUS_PROPOSE_UPDATE,
        code=CODE_CONSISTENT_PROGRESS,
        proposed_receipt=copy.deepcopy(selected),
        evidence_refs=evidence_refs,
    )


# ---------------------------------------------------------------------------
# Result construction
# ---------------------------------------------------------------------------

def _make_result(
    attempt: dict,
    status: str,
    code: str,
    proposed_receipt,
    evidence_refs: list,
) -> dict:
    result = {
        "schema_version": DECISION_SCHEMA,
        "action_id": attempt["action_id"],
        "attempt_no": attempt["attempt_no"],
        "payload_sha256": attempt["payload_sha256"],
        "status": status,
        "code": code,
        "proposed_receipt": proposed_receipt,
        "evidence_refs": list(evidence_refs),
        "journal_mutation_required": status == STATUS_PROPOSE_UPDATE,
        "resend_authorized": False,
    }
    assert tuple(result.keys()) == _RESULT_KEYS
    return result