"""F1-23: диагностическая проекция доступности провайдерных каналов кампании.

Чистый модуль по CONTRACT.md: без I/O, сети, SQL, окружения, часов и случайности.
Время приходит только через аргумент ``now``. Результат никогда не разрешает
внешних эффектов (``external_effect_authorized`` всегда ``False``).
"""
from datetime import datetime, timedelta, timezone
from uuid import UUID

__all__ = ("ProviderObservationError", "evaluate_provider_observations")

INPUT_SCHEMA_VERSION = "FIRST_PROVIDER_OBSERVATION_INPUT_V1"
OUTPUT_SCHEMA_VERSION = "FIRST_PROVIDER_OBSERVATION_V1"

_ROOT_KEYS = frozenset(
    ("schema_version", "scope", "observations", "required_channels", "max_age_seconds")
)
_SCOPE_KEYS = ("client_id", "runtime_campaign_id", "mailbox_ref")
_ROW_KEYS = frozenset(("channel", "status", "observed_at", "check_ref"))
_CHANNELS = frozenset(("INBOX", "OUTBOUND", "HANDOFF"))
_STATUSES = frozenset(("OK", "FAILED", "UNAVAILABLE"))

_MAX_OBSERVATIONS = 16
_MAX_REQUIRED_CHANNELS = 3
_MAX_ID_BYTES = 128
_MIN_AGE_SECONDS = 1
_MAX_AGE_SECONDS = 86400

_CODES = frozenset(
    (
        "INVALID_INPUT",
        "INVALID_SCOPE",
        "INVALID_POLICY",
        "INVALID_OBSERVATION",
        "DUPLICATE_CHANNEL",
        "FUTURE_OBSERVATION",
    )
)


class ProviderObservationError(ValueError):
    """Ошибка контракта; ``code`` — нормативный код, сообщение равно коду."""

    def __init__(self, code):
        if type(code) is not str or code not in _CODES:
            raise TypeError("unknown ProviderObservationError code")
        super().__init__(code)
        self._code = code

    @property
    def code(self):
        return self._code

    def __str__(self):
        return self._code


def _has_exact_keys(value, expected):
    """Exact dict с ключами — exact builtin str, ровно ``expected``."""
    if type(value) is not dict or len(value) != len(expected):
        return False
    for key in value:
        if type(key) is not str:
            return False
    return value.keys() == set(expected)


def _is_valid_id(value):
    if type(value) is not str:
        return False
    # Каждый символ занимает минимум один байт UTF-8: длинные строки отсекаем сразу.
    if not value or len(value) > _MAX_ID_BYTES:
        return False
    for ch in value:
        point = ord(ch)
        if point <= 0x1F or point == 0x7F or 0xD800 <= point <= 0xDFFF or ch.isspace():
            return False
    # После исключения суррогатов кодирование в UTF-8 не может завершиться ошибкой.
    return len(value.encode("utf-8")) <= _MAX_ID_BYTES


def _is_canonical_uuid(value):
    try:
        return str(UUID(value)) == value
    except (ValueError, TypeError, AttributeError):
        return False


def _is_enum(value, allowed):
    return type(value) is str and value in allowed


def _normalize_now(now):
    """UTC-копия aware ``now`` или None, если значение недопустимо."""
    if type(now) is not datetime:
        return None
    try:
        if now.utcoffset() is None:
            return None
        return now.astimezone(timezone.utc)
    except Exception:  # пользовательский tzinfo не должен выпускать внутренние ошибки
        return None


def _parse_observed_at(value):
    """Разобранный UTC datetime для канонической строки или None."""
    if type(value) is not str:
        return None
    try:
        parsed = datetime.fromisoformat(value)
        offset = parsed.utcoffset()
        if offset is None or offset != timedelta(0):
            return None
        if parsed.astimezone(timezone.utc).isoformat() != value:
            return None
        return parsed.astimezone(timezone.utc)
    except (ValueError, TypeError, OverflowError):
        return None


def _validate_row(row):
    """Кортеж (channel, status, observed_at, check_ref) или None для дефектной строки."""
    if not _has_exact_keys(row, _ROW_KEYS):
        return None
    channel = row["channel"]
    status = row["status"]
    check_ref = row["check_ref"]
    if not _is_enum(channel, _CHANNELS) or not _is_enum(status, _STATUSES):
        return None
    if not _is_valid_id(check_ref):
        return None
    observed_at = _parse_observed_at(row["observed_at"])
    if observed_at is None:
        return None
    return channel, status, observed_at, check_ref


def evaluate_provider_observations(snapshot: dict, *, now: datetime) -> dict:
    # Этап 1: корневая форма, observations как список, now.
    if not _has_exact_keys(snapshot, _ROOT_KEYS):
        raise ProviderObservationError("INVALID_INPUT")
    schema_version = snapshot["schema_version"]
    if type(schema_version) is not str or schema_version != INPUT_SCHEMA_VERSION:
        raise ProviderObservationError("INVALID_INPUT")
    observations = snapshot["observations"]
    if type(observations) is not list or len(observations) > _MAX_OBSERVATIONS:
        raise ProviderObservationError("INVALID_INPUT")
    now_utc = _normalize_now(now)
    if now_utc is None:
        raise ProviderObservationError("INVALID_INPUT")

    # Этап 2: scope целиком.
    scope = snapshot["scope"]
    if not _has_exact_keys(scope, _SCOPE_KEYS):
        raise ProviderObservationError("INVALID_SCOPE")
    for key in _SCOPE_KEYS:
        if not _is_valid_id(scope[key]):
            raise ProviderObservationError("INVALID_SCOPE")
    if not _is_canonical_uuid(scope["runtime_campaign_id"]):
        raise ProviderObservationError("INVALID_SCOPE")

    # Этап 3: политика; timedelta строится только из проверенного значения.
    required_channels = snapshot["required_channels"]
    if type(required_channels) is not list or not (
        1 <= len(required_channels) <= _MAX_REQUIRED_CHANNELS
    ):
        raise ProviderObservationError("INVALID_POLICY")
    required = set()
    for channel in required_channels:
        if not _is_enum(channel, _CHANNELS) or channel in required:
            raise ProviderObservationError("INVALID_POLICY")
        required.add(channel)
    max_age_seconds = snapshot["max_age_seconds"]
    if type(max_age_seconds) is not int or not (
        _MIN_AGE_SECONDS <= max_age_seconds <= _MAX_AGE_SECONDS
    ):
        raise ProviderObservationError("INVALID_POLICY")
    max_age = timedelta(seconds=max_age_seconds)

    # Этап 4: строки последовательно; первая ошибочная строка определяет код.
    seen = {}
    for row in observations:
        parsed = _validate_row(row)
        if parsed is None:
            raise ProviderObservationError("INVALID_OBSERVATION")
        channel, status, observed_at, check_ref = parsed
        if channel in seen:
            raise ProviderObservationError("DUPLICATE_CHANNEL")
        if observed_at > now_utc:
            raise ProviderObservationError("FUTURE_OBSERVATION")
        seen[channel] = (status, observed_at, check_ref)

    reasons = []
    for channel in sorted(required):
        observation = seen.get(channel)
        if observation is None:
            reasons.append({"channel": channel, "code": "MISSING", "check_ref": None})
            continue
        status, observed_at, check_ref = observation
        if status == "FAILED" or status == "UNAVAILABLE":
            code = status
        elif now_utc - observed_at > max_age:
            code = "STALE"
        else:
            continue
        reasons.append({"channel": channel, "code": code, "check_ref": check_ref})

    return {
        "schema_version": OUTPUT_SCHEMA_VERSION,
        "scope": {key: scope[key] for key in _SCOPE_KEYS},
        "status": "DEGRADED" if reasons else "OBSERVED_OK",
        "reasons": reasons,
        "observed_channels": sorted(seen),
        "external_effect_authorized": False,
    }
