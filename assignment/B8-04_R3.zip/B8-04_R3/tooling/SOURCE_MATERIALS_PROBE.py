"""PROVIDED owner/codec source feasibility; never candidate service acceptance."""
from pathlib import Path
import base64,copy,hashlib,json,sys
from datetime import datetime
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'reference_source'),str(ROOT/'tooling')]
from bundle_codec import validate_bundle,BundleError
from material_codec import canonical,descriptor,verify_record,intent_from_material
from sales_discovery_qualification import qualify_candidate,QualificationError
from sales_runtime_materialization import prepare_bound_materials
from sales_outbound_intent import OutboundIntentError
from sales_rules import RuleViolation
bundle=json.loads((ROOT/'acceptance/materials_bundle.json').read_text())
q=json.loads((ROOT/'acceptance/qualification_inputs.json').read_text());now=datetime.fromisoformat(q['now'])
scope={'client_id':q['candidate']['client_id'],'campaign_id':q['candidate']['runtime_campaign_id'],'lead_id':'lead-a','mailbox_ref':'mailbox-a','thread_id':None}
assert hashlib.sha256(q['source_utf8'].encode()).hexdigest()==q['assessment']['source_content_sha256']
qual=qualify_candidate(q['candidate'],q['assessment'],binding=q['binding'],policy=q['policy'],now=now)
assert qual['verdict']=='QUALIFIED_FOR_PREPARATION'
decoded=validate_bundle(bundle,scope={k:scope[k] for k in ('client_id','campaign_id')},now=now,bundle_ref='bundle-a')
for template,kind,thread in [('opening','SEND',None),('explain','REPLY','thread-a')]:
 scope['thread_id']=thread;staged=[]
 material=prepare_bound_materials(decoded['loaded_registry'],decoded['raw_config'],now=now,locale='en-GB',required_template_id=template,pinned_pack_version='en-v1',save_materials=lambda x:staged.append(copy.deepcopy(x)) or x)
 assert len(staged)==1
 raw=(json.dumps(material,ensure_ascii=False,indent=2)+'\n').encode();digest=hashlib.sha256(raw).hexdigest()
 d={'material_ref':'material-'+template,'sha256':digest,'approved_fact_ids':material['fact_ids']}
 record={'scope':copy.deepcopy(scope),'catalog_version':'v1','bundle_ref':'bundle-a','material_ref':d['material_ref'],'rendered':{'utf8_b64':base64.b64encode(raw).decode(),'sha256':digest},'pins':decoded['pins'],'locale':'en-GB','template_id':template,'pack_version':'en-v1'}
 got=verify_record(d,record,scope=scope,catalog_version='v1',bundle=bundle,now=now);assert got==material
 out=intent_from_material(got,scope=scope,action_id='action-a',event_id='occurrence-a',expected_revision=1,policy_version='policy-a',binding_version='binding-v1',recipient_ref='lead-a',kind=kind)
 assert out['action']['payload']['subject']==material['subject'];assert out['action']['payload']['body']==material['body']
 for mutation,code in [('hash','HASH_MISMATCH'),('scope','FOREIGN_SCOPE'),('pins','PIN_MISMATCH'),('facts','FACT_SCOPE_MISMATCH')]:
  bad=copy.deepcopy(record);dd=copy.deepcopy(d)
  if mutation=='hash':dd['sha256']='f'*64
  if mutation=='scope':bad['scope']['client_id']='foreign'
  if mutation=='pins':bad['pins']['config_sha256']='f'*64
  if mutation=='facts':dd['approved_fact_ids']=['foreign']
  try:verify_record(dd,bad,scope=scope,catalog_version='v1',bundle=bundle,now=now)
  except BundleError as e:assert str(e)==code,(mutation,e)
  else:raise AssertionError(mutation)
 print('PASS exact F130 staging+archive verification+F114',kind,'and hash/scope/pins/facts negatives')
foreign=copy.deepcopy(q['assessment']);foreign['client_id']='foreign'
try:qualify_candidate(q['candidate'],foreign,binding=q['binding'],policy=q['policy'],now=now)
except QualificationError as e:assert e.code=='SCOPE_MISMATCH'
else:raise AssertionError('foreign assessment accepted')
stale=copy.deepcopy(q['assessment']);stale['source_observed_at']='2026-10-14T11:00:00+00:00'
assert qualify_candidate(q['candidate'],stale,binding=q['binding'],policy=q['policy'],now=now)['verdict']=='NEEDS_REVIEW'
# Original unmodified RU explain has nonempty R3 subject. Explicit bad consumer test zero callback.
bad=copy.deepcopy(decoded['loaded_registry']);bad['packs_by_locale']['en-GB']['templates']['explain']['subject']='  ';calls=[]
try:prepare_bound_materials(bad,decoded['raw_config'],now=now,locale='en-GB',required_template_id='explain',pinned_pack_version='en-v1',save_materials=lambda x:calls.append(x))
except RuleViolation:pass
else:raise AssertionError('empty subject consumer accepted')
assert calls==[]
print('PASS exact F129 qualification/source scope/stale; F130 consumer rejection zero callback')
print('SOURCE/OWNER CODEC FEASIBILITY ONLY; candidate/PG/installation/presentation transport NOT_RUN')

for bad_id in [' fact ', 'fact\n', 'fact\x00', 'fact\x7f', 'x'*129, '', True]:
    try:descriptor({'material_ref':'material-a','sha256':'a'*64,'approved_fact_ids':[bad_id]})
    except BundleError as e:assert str(e)=='INVALID_MATERIAL_DESCRIPTOR'
    else:raise AssertionError('invalid fact identifier accepted')
assert descriptor({'material_ref':'material-a','sha256':'a'*64,'approved_fact_ids':['x'*128]})['approved_fact_ids']==['x'*128]
print('PASS descriptor fact IDs reject whitespace/control/DEL/overlength/empty/bool; 128-char boundary accepted')
