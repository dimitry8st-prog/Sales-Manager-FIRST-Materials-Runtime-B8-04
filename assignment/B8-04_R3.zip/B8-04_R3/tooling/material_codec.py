"""PROVIDED pure codecs/probe support; no service, persistence, authority or I/O."""
import base64,copy,hashlib,json,re
from bundle_codec import decode_blob,validate_bundle,require
from sales_runtime_materialization import prepare_bound_materials
from sales_outbound_intent import build_outbound_intent

def canonical(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')

def descriptor(value):
    require(type(value) is dict and set(value)=={'material_ref','sha256','approved_fact_ids'},'INVALID_MATERIAL_DESCRIPTOR')
    ref=value['material_ref']; require(type(ref) is str and 0<len(ref)<=128 and ref.strip()==ref and not any(ord(c)<32 or ord(c)==127 for c in ref),'INVALID_MATERIAL_DESCRIPTOR')
    require(type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}',value['sha256']),'INVALID_HASH')
    facts=value['approved_fact_ids'];require(type(facts) is list and all(type(x) is str and 0<len(x)<=128 and x.strip()==x and not any(ord(c)<32 or ord(c)==127 for c in x) for x in facts) and len(set(facts))==len(facts),'INVALID_MATERIAL_DESCRIPTOR')
    return copy.deepcopy(value)

def verify_record(value,record,*,scope,catalog_version,bundle,now):
    """Owner-side verifier after authenticated immutable scoped lookup, BEFORE store.
    Lookup authenticates record/ref; hash equality alone does not supply authority.
    No lookup/network/storage here. Record contains exact 9-field F122 bytes.
    """
    d=descriptor(value)
    require(type(record) is dict and set(record)=={'scope','catalog_version','bundle_ref','material_ref','rendered','pins','locale','template_id','pack_version'},'INVALID_MATERIAL_RECORD')
    require(record['scope']==scope,'FOREIGN_SCOPE')
    require(record['catalog_version']==catalog_version and record['material_ref']==d['material_ref'],'MATERIAL_REF_MISMATCH')
    decoded=validate_bundle(bundle,scope={k:scope[k] for k in ('client_id','campaign_id')},now=now,bundle_ref=record['bundle_ref'])
    require(record['pins']==decoded['pins'],'PIN_MISMATCH')
    require(record['rendered']['sha256']==d['sha256'],'HASH_MISMATCH')
    rendered=decode_blob(record['rendered'])
    exact=prepare_bound_materials(decoded['loaded_registry'],decoded['raw_config'],now=now,locale=record['locale'],required_template_id=record['template_id'],pinned_pack_version=record['pack_version'],save_materials=lambda x:copy.deepcopy(x))
    require(rendered==exact,'MATERIAL_CONTENT_MISMATCH')
    require(d['approved_fact_ids']==exact['fact_ids'],'FACT_SCOPE_MISMATCH')
    return copy.deepcopy(exact)

def intent_from_material(material,*,scope,action_id,event_id,expected_revision,policy_version,binding_version,recipient_ref,kind):
    """Exact pure F114 conversion: attachment transport is NOT added to frozen DTO."""
    payload={'recipient_ref':recipient_ref,'subject':material['subject'],'body':material['body']}
    s=copy.deepcopy(scope);s['runtime_campaign_id']=s.pop('campaign_id')
    return build_outbound_intent({'schema_version':'FIRST_ACTION_INTENT_V1','action_id':action_id,'scope':s,'expected_state_revision':expected_revision,'event_id':event_id,'kind':kind,'policy_version':policy_version,'locale':material['locale'],'language_pack_version':material['language_pack_version'],'template_id':material['template_id'],'fact_ids':material['fact_ids'],'payload':payload,'payload_sha256':hashlib.sha256(canonical(payload)).hexdigest(),'binding_version':binding_version})
