# Отдельному инженеру внедрения

После независимой приёмки переносить только allowlist module/test/fixtures; source56 не заменять целиком устаревшей копией. Сверить фактический deployed snapshot отдельно. F106 accepted exact API использовать без изменений. Принятый F120 в будущем сохраняет selected template_id вместе с BOUND; до этого только frozen protocol fixtures, никакого рабочего import.

Перед подготовкой материала сравнить exact pinned versions and source. F122 output mapping subject/body/fact_ids в F114 делать только через принятый контракт payload; не добавлять QA/grant flags. Полный HANDOFF context F119/F109 передаётся отдельно. Resolve ru-RU whitelist sales_preparation_contract в собственной интеграционной задаче, с регрессией gates. Не обходить owner approval, locks, sending readiness, contact/source/materials QA. Проверить все kinds EN/RU на реальных одобренных packs в отдельной пилотной настройке. F122 PASS не закрывает FG04/FG06 и не увеличивает readiness автоматически.
