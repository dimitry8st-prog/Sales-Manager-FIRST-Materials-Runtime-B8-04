# IMPLEMENTATION — F1-30 (sales_runtime_materialization), revision R2

## Последовательность реализации

Адаптер — чистая композиция трёх принятых компонентов и consumer-валидации,
без собственных правил (соблюдал п.2 ТЗ: импорт `bind_action_locale`,
`materialize_bound_template` и `validate_materials`, их логика не копируется;
п.1 возврата R1 учтён — consumer-валидация встроена в адаптер):

1. `bind_action_locale(loaded_registry, binding_config, now=now, locale=locale,
   required_template_id=required_template_id, pinned_pack_version=pinned_pack_version)`
   — точные входы ABI; исходные ошибки проходят как есть.
2. `materialize_bound_template(loaded_registry, bound_language,
   template_id=required_template_id)` — тот же объект реестра и выбранный
   template ID; выход FIRST_TEMPLATE_MATERIALS_V1 — точный F122-словарь.
3. `validate_materials(materials)` — consumer-валидация точного F122-словаря
   ДО любого сохранения; отказ (в т.ч. `MISSING_SUBJECT` на QUESTION с пустой
   темой) проходит исходным объектом `RuleViolation`, callback не вызывается.
4. `return save_materials(materials)` — вызов ровно один раз с исходным
   словарём (результат `validate_materials` игнорируется — тема/текст никогда
   не исправляются без согласия); без добавочных полей, нормализации пробелов,
   перевода, слияния и агентского текста; результат callback возвращается
   как есть (без обёртки и копирования).

Патч-импорт зависимостей — plain imports; пути `src`/`reference` поднимает
тестовый harness (как в `tests/test_public.py`); модуль не трогает `sys.path`.

## Ошибки

Собственного перехвата/обработки в модуле нет — по CONTRACT.json R2
(`errors: Dependency/callback/consumer exceptions propagate same object;
rejection means zero callback calls`):

- ошибки bind (ActionLocaleError/FirstBindingError/LanguageRegistryError +
  INVALID_INPUT) — пропускаются исходными, callback не вызывается;
- ошибки materialize (TemplateMaterializationError) — пропускаются исходными,
  callback не вызывается (validate-стадия не достигается);
- ошибки consumer-валидации (`RuleViolation`) — пропускаются исходным
  объектом (identity), callback не вызывается (zero save);
- ошибки callback — пропускаются исходным объектом (identity), после ровно
  одного вызова, ПОСЛЕ успешной валидации;
- на любом отказе до callback — zero save; никакого fallback, повторного
  сохранения, синтетического агентского текста и изменения входов; внешние
  SEND_READY/разрешения отправки не вводятся (forbidden CONTRACT;
  real sales_store.save_materials не вызывается).

Поверхности исключений зависимостей, consumer-валидации и callback сведены
в таблицу exception-surface (обе стороны контракта; пометки словаря знания):
строки bind/materialize/save — SPEC; три отказа consumer на F122-словаре
(INVALID_MATERIALS / MISSING_SUBJECT / MISSING_BODY) — SPEC
(`RuleViolation`, ловятся тестами); ветки attachments (INVALID_ATTACHMENTS /
INVALID_ATTACHMENT) — SPEC:UNREACHABLE (F122-словарь имеет ровно 9 ключей,
ключа `attachments` в материале нет по контракту);
`TypeError` от не-callable save_materials передаётся как ошибка callback
(NONSPEC:TREATED, пропущен исходный); RecursionError на глубоких структурах
внутри зависимостей пропускается (NONSPEC:TREATED, правило пропуска исходных
ошибок) — адаптер не углубляет структуры и не создаёт путей; самостоятельного
I/O и записи в stdout/stderr адаптер не выполняет.

## Тесты

- **Публичные** `tests/test_public.py` (5 тестов, R2-редакция): положительные
  EN/RU/третья локаль на `runtime_initial_*` с самостоятельной
  consumer-валидацией внутри save; QUESTION с пустой темой — refusal
  consumer тем же типом/сообщением, что у адаптера, zero save, снапшот без
  изменений; пустая body — тип/код зависимости, zero save; отказа bind
  (drift/template/fact) — zero save; identity ошибки callback при ровно одном
  вызове.
- **Собственные** `tests/test_candidate_f130.py` (9 тестов), дополняют, не
  заменяют (п.5 RETURN_GUIDE):
  1. `test_positive_runtime_initial_exact_en_ru_de` — положительные на
     `runtime_initial_{en,ru,de}.json`: точный F122-выход, ровно один save,
     validate-стадия получает тот же объект (assertIs identity),
     результат callback и входы без изменений;
  2. `test_question_blank_subject_zero_save_same_code` — QUESTION с пустой
     темой на reference-фикстуре: `MISSING_SUBJECT` исходным исключением,
     zero save, inputs immutable;
  3. `test_validate_error_identity_passes_through_unwrapped` — identity
     исходного объекта consumer-ошибки (sentinel-`RuleViolation` под
     подменой validate — assertIs);
  4. `test_materialize_failure_zero_save_original_error` — отказ
     материализации с временной подменой зависимости: исходное исключение,
     zero save, validate-стадия не достигнута;
  5. `test_bind_materialize_validate_exact_abi_inputs` — точность ABI всех
     трёх стадий (bind/materialize/validate); validate и save получают один
     и тот же объект F122-словаря;
  6. `test_save_gets_original_dict_not_validate_return` — «не дописывать»:
     save получает исходный dict, даже если validate вернул значение;
  7. `test_pinned_drift_rejection_zero_save_inputs_immutable` — drift
     закреплённой версии по трём фикстурам: `PACK_VERSION_CHANGED`, zero
     save, входы неизменны (уход до validate-стадии);
  8. `test_subject_passes_byte_exact_when_dependency_yields_spaced` —
     против «нормализации пробелов»: subject зависимости передаётся байт-
     точно («  spaced  » остаётся «  spaced  »);
  9. `test_callback_exception_identity_after_materialize` — исходный объект
     ошибки callback (assertIs) после материализации и валидации, ровно один
     вызов.

Прогоны (команды и коды — в `return/test.log`): `python -E -B
CHECK_PACKAGE.py` → PROTECTED_PASS, exit 0; `python -E -B -m unittest
discover -s tests -v` → 14/14 OK, exit 0 (5 публичных R2 + 9 собственных);
исходные dependency-сьюты: `reference` wave3 → 32/32 OK, wave4 → 30/30 OK,
exit 0. Consumer-validation на runtime_initial-фикстурах: POSITIVE×3
(exact F122 в save) + REJECTION (MISSING_SUBJECT, zero save) — отдельные
строки RESULT.json.

## Граница доверия (NOT_RUN / NOT_CONNECTED)

- Это **компонентный** результат: actual wiring в
  `sales_manager.process_prepare` (стадия GOLD_AUDITED), реальное
  `sales_store.save_materials` (AUTO policy / SEND_QUEUED / постановка
  `sales.send` в очередь — по INTEGRATION.md эффект сохранения не
  моделируется), БД, сеть, миграции, worker и отправка — **NOT_RUN /
  NOT_CONNECTED** (`integration_status = NOT_CONNECTED`).
- Данные и время — синтетические фикстуры ТЗ; живых писем, реальных кампаний
  и исходящих эффектов нет (`external_effect_authorized = false`).
- Аудит собственных тестов целевыми мутантами копии модуля (санитарная
  проверка способности тестов ловить дефекты; подробности не входят в
  контракт сдачи) выполнен: 9/9 целевых мутантов ловятся (kill-rate 9/9) —
  пропуск validate-стадии, стрип-подмена через возврат validate, проглатывание
  RuleViolation, fallback к агентскому тексту на отказе consumer, слияние
  полей, повторное сохранение, проглатывание ошибки callback, возврат
  материалов вместо результата callback, нормализация пробелов.