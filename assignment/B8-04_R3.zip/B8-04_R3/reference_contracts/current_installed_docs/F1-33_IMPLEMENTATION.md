# F1-33 R1 — реализация connect_with_deadlines

Проект: `sales-manager-first`. Модуль: `source/first_db_bootstrap.py`. Собственные тесты: `tests/test_first_db_bootstrap.py`.

## Что делает функция

`connect_with_deadlines(connect_factory, connection_kwargs, policy)` проверяет явную policy и kwargs, собирает новый словарь kwargs с двумя ограничениями (connect timeout и session options для SQL/lock) и один раз вызывает `connect_factory(**new_kwargs)`. Возвращается ровно тот объект, который вернула фабрика, без обёртки.

## Валидация (до вызова фабрики)

Любое нарушение даёт `ValueError("INVALID_DB_DEADLINE_INPUT")`, фабрика при этом не вызывается:

- `connect_factory` — callable;
- `connection_kwargs` — точно `dict` (`type(...) is dict`), все ключи — `str` или подклассы `str` (`isinstance(key, str)`);
- в `connection_kwargs` нет ключей `options`, `connect_timeout`, `conninfo`, `dsn` (конфликт отклоняется, а не сливается и не перезаписывается);
- `policy` — точно `dict` с ровно тремя ключами: `connect_timeout_seconds`, `statement_timeout_ms`, `lock_timeout_ms`;
- значения policy — точно `int` (`type(v) is int`, `bool` отклоняется);
- `connect_timeout_seconds` 1..60; `statement_timeout_ms` 1..60000; `lock_timeout_ms` 1..60000; `lock_timeout_ms <= statement_timeout_ms`.

Значений по умолчанию нет: policy передаёт интегратор явно. Сообщение ошибки не содержит значений kwargs.

## Копирование kwargs

`new_kwargs = dict(connection_kwargs)` — новый словарь верхнего уровня; значения (в том числе вложенные объекты, `row_factory`) сохраняют identity и не копируются и не изменяются. Исходные `connection_kwargs` и `policy` не мутируются.

## Формат добавляемых параметров

- `connect_timeout` = `<connect_timeout_seconds>` (int);
- `options` = `-c statement_timeout=<statement_timeout_ms> -c lock_timeout=<lock_timeout_ms>`.

Пример для policy 3 / 2500 / 700: `connect_timeout=3`, `options='-c statement_timeout=2500 -c lock_timeout=700'`.

## Чего в компоненте нет

Нет retry и sleep, нет логирования и print, нет чтения environment, нет import-time I/O, нет импорта psycopg, нет обращений к БД кроме инъектированной фабрики. Исключения фабрики (в том числе `BaseException`) пробрасываются без изменений. Нет слияния DSN/options и интерполяции SQL.

## Integration note для postgres_store._connect_once

Это описание для инженера внедрения; **runtime integration не выполнялась**, `references/postgres_store.py` не менялся.

- В `_connect_once` заменить только создание соединения `psycopg.connect(**existing_kwargs)` на `connect_with_deadlines(psycopg.connect, existing_kwargs, explicit_server_policy)`.
- host / cloudsql path / port / dbname / user / password / row_factory передавать без изменений.
- Существующий `postgres_store.connect` (3 попытки, backoff 1 и 2 с) не менять; новый слой retry не добавлять.
- Значения policy выбирает интегратор из server configuration; значения из `fixtures/examples.json` синтетические, не deployment defaults.
- Если в existing kwargs уже есть `options`, `connect_timeout` или DSN, это будет `INVALID_DB_DEADLINE_INPUT`, а не слияние.
- Не печатать kwargs и не возвращать credentials в ошибках.
- Лимиты ограничивают отдельные SQL-запросы и ожидание блокировок, а не общий дедлайн задачи; DNS/сеть и суммарный бюджет retry нужно измерять отдельно.
- Откат: отключить новый callsite, вернуть сохранённый оригинальный hook, удалить только принятые модуль/тест/доки. Изменений данных БД и миграций нет.

## Результаты собственных проверок

`python run_checks.py`: 17 тестов (6 публичных + 11 собственных), OK, без skip. `python check_protected.py`: `PROTECTED_PASS`. Тесты на spy-фабрике доказывают только построение kwargs, но не атомарность PostgreSQL и не фактические session settings.

## NOT_RUN (требуются на стадии инженера, disposable localhost PostgreSQL)

- `SHOW statement_timeout` / `SHOW lock_timeout` подтверждают заданные значения;
- `SELECT pg_sleep(...)` сверх лимита завершается ошибкой в ожидаемых пределах;
- удерживаемая блокировка строки даёт ошибку по `lock_timeout`;
- обычная транзакция и rollback проходят;
- connection refused / ожидание ограничено `connect_timeout` и существующим retry;
- отсутствие секретов в raw logs;
- реальная проверка, что psycopg/libpq принимает `options` и `connect_timeout`;
- подключение к `postgres_store._connect_once` и любая runtime-проверка.

Пока эти проверки не выполнены, корректность дедлайнов в реальном PostgreSQL не заявляется.
