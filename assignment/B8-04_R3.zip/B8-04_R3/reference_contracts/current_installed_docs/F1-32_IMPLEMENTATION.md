# F1-32 — реализация

## Реализация
`source/first_owned_transition.py`, функция `run_owned_transition(conn, lease_store, *, task_id, owner_token, generation, transition, update)`.

Последовательность (CONTRACT.json → `abi.order`):

1. Полная проверка входов, до любых вызовов портов.
2. `lease_store.assert_owned(conn, task_key=task_id, owner_token=owner_token, generation=generation)`
3. `result = update(conn)`
4. `lease_store.finish_owned_in_tx(conn, task_key=task_id, owner_token=owner_token, generation=generation)`
5. `return result` — тот же объект, без копирования.

Проверки входов (любое нарушение → `ValueError("INVALID_OWNED_TRANSITION_INPUT")`, ни один порт не вызывается):

| Поле | Правило |
|---|---|
| `conn` | не `None` |
| `lease_store` | не `None`, есть вызываемые `assert_owned` и `finish_owned_in_tx` |
| `update` | `callable` |
| `task_id` | ровно `str`, длина 1..128, `[A-Za-z0-9_.:-]+` (ASCII, `fullmatch`) |
| `owner_token` | ровно `str`, каноничный UUID (нижний регистр, 36 символов; та же проверка, что в F1-16) |
| `generation` | `type is int` (не `bool`), `>= 1` |
| `transition` | одно из `finish`, `fail`, `defer` |

Публичное сообщение об ошибке намеренно не содержит имя поля или причину: контракт требует ровно `INVALID_OWNED_TRANSITION_INPUT`. Для диагностики конкретных границ и полей служат собственные тесты с именованными subTest.

Для `owner_token` длина 36 проверяется до `uuid.UUID`: парсер принимает также компактную, URN и заключённую в фигурные скобки запись, а контракт допускает только каноничную форму.

`task_id`, `owner_token`, `generation` и `conn` передаются портам без изменений. `transition` только проверяется: SQL каждого перехода находится в callback интегратора.

## Что адаптер НЕ делает
Не открывает соединение, не делает commit/rollback/close, не ловит ошибки портов (любой `BaseException` проходит как есть, с тем же объектом), не вызывает `task_store.complete_task/fail_task/defer_task`, не трогает claim/renew/recovery/worker и D2. Адаптер не может проверить, что `update` соблюдает контракт (только `conn`, без commit, без провайдерского I/O) — это проверяет инженер внедрения.

## Собственные проверки
`tests/test_first_owned_transition.py` (20 тестов): порядок assert → update → finish для всех трёх переходов; одинаковые kwargs у assert и finish; тождество результата (`assertIs`) для разных объектов; граничные значения; негативные входы по каждому полю, включая подклассы `str`, `True`, `1.0`, `\n` в конце `task_id`, не-ASCII цифры, верхний регистр UUID; битые порты (нет метода, не callable, property с исключением); ноль вызовов портов и `update` при невалидном входе; тождество исключений и отсутствие вызовов дальше по цепочке при ошибке в assert / update / finish (включая `BaseException`, `KeyboardInterrupt`, `SystemExit`); `commit/rollback/close/execute/cursor` на conn не вызываются; каждый порт и `update` вызываются ровно один раз.

## Результаты
`python run_checks.py`: `PROTECTED_PASS`, 28 тестов (8 public + 20 own), OK, без skip. Подробности — `raw_checks.txt`.

## Ограничения
Тесты со шпионами доказывают только протокол вызовов. Они НЕ доказывают атомарность и откат PostgreSQL и не проверяют реальные session settings.

## Совместимость
Python 3, только стандартная библиотека (`re`, `uuid`). Frozen F1-16 (`assert_owned`, `finish_owned_in_tx`) и `references/**` не менялись.

## Передача инженеру
См. `INTEGRATION.md` и `RETURN_REPORT.md` (карта внедрения, NOT_RUN).
