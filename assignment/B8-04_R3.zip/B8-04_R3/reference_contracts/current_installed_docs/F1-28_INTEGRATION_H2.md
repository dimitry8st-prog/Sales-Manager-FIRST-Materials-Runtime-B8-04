# Инженеру внедрения

В sales_manager.process_discover после sales_store.get_campaign(campaign_id) и до использования campaign для _discovery_payload получить projection через adapter. В process_prepare после загрузки campaign для lead.campaign_id и до build_payload аналогично получить binding. Существующий runtime campaign dict не заменять плоской проекцией: build_payload/_discovery_payload ожидают прежнюю форму; конкретное использование validated поля подключает один инженер после проверки consumer schema.

Before: runtime config может читаться разрозненно из campaign/payload. After: отдельный trusted resolve_config(campaign_id) возвращает F105, adapter даёт проверенную F112 projection. Campaign/payload с поддельной config не выбирают источник. Серверный resolver в текущей границе не реализован: без него fail closed TRUSTED_RESOLVER_REQUIRED, integration NOT_CONNECTED. Не копировать projection в task payload. Сохранять status/replay/active lead guards, mailbox/live/gold checks и NO_OUTBOUND.

Перед merge проверить fresh SHA references относительно SOURCE. Подключение и E2E/DB проверки выполняет инженер отдельно. Rollback: сначала отключить consumer hook, затем удалить только новый module; frozen deps и существующие задачи не менять. Все current package tests — offline component, E2E/PG/live NOT_RUN.

## Исправленная передача H2 (technical ABI R1)
Прямое подключение F128 projection к F129 binding запрещено: F112 возвращает 18 полей FIRST_CAMPAIGN_PROJECTION_V1, F110 принимает ровно пять полей FIRST_QUALIFICATION_BINDING_V1. Инженер внедрения владеет механическим mapper reference/qualification_binding_mapper.py: schema_version заменяется на FIRST_QUALIFICATION_BINDING_V1, а client_id/runtime_campaign_id/offer_id/binding_version копируются без преобразований. Остальная projection сохраняется для других consumers; её не обрезать in-place. Новый кандидатский adapter API не меняется.

```python
projection = resolve_campaign_projection(campaign, resolve_config=trusted_config_resolver, now=now)
qualification_binding = projection_to_qualification_binding(projection)
result = qualify_and_ingest(candidate, binding=qualification_binding, policy=trusted_policy,
    resolve_assessment=trusted_assessment_resolver, ingest=reviewed_ingest_closure, now=now)
```
Код mapper поставлен как frozen integration-owner reference, не задание кандидату и не изменение accepted F110/F112. tests/test_integration_mapping.py доказывает actual F112→mapper→actual F110; внешний control proof отдельно проверяет ту же цепь через candidate ABI с контрольными реализациями. Scaffolds в пакете намеренно остаются RED.

F128 projection НЕ содержит raw approved_facts с текстами/source_ref и полного offer. F130 должен получать исходный trusted F105 config отдельно через серверный resolver из того же authoritative campaign/binding_version, а не реконструировать config из projection. Никаких task-payload fallback или выдуманных фактов. Источник config, candidate identity, assessment/policy producers ещё не подключены. Пакет остаётся PREPARED_NOT_ISSUED, integration NOT_CONNECTED.
