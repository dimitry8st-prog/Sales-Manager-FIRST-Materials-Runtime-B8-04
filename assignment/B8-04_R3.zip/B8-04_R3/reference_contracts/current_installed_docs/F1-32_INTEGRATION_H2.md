# Передача инженеру внедрения F1-32 — H2

Технический component contract R1 сохранён. H2 исправляет integration-only exception/ownership требования; новый runtime здесь не реализован.

Consumer: worker.run_once terminal result/defer/fail branches and corresponding task_store SQL. Candidate must not edit shared files. Add adapter after checking current accepted F116 bytes. Existing old complete_task/fail_task/defer_task each opens own conn and MUST NOT be called inside this callback.

One integration owner constructs active transaction on same PostgreSQL database/schema as exact lease. Both lease store and task_id mapping task_key=task_id must be verified. Opening a psycopg connection context alone leaves transaction IDLE; enter conn.transaction() before calling F116, which validates INTRANS before any SQL. Caller pseudo-code:

```python
with postgres_store.connect() as conn:
    with conn.transaction():  # explicit BEGIN: F116 requires INTRANS, not IDLE
        def update(current_conn):
            # SAME existing task transition SQL: WHERE task_id=%s AND status='RUNNING'.
            # Bind parameters; add RETURNING; zero rows => raise conflict.
            # Use current_conn.cursor(); no new connection and no commit/rollback/close.
            return actual_updated_row
        row = run_owned_transition(conn, lease_store, task_id=task_id,
            owner_token=owner_token, generation=generation, transition='finish', update=update)
# Exiting transaction successfully commits both lease and task result together.
```

For fail/defer use existing CASE/backoff/attempt semantics from task_store and transition labels exactly; adapter does not rewrite SQL. The integration owner must review concrete callback SQL and rowcount guards, and protect claim/renew generation transport. Callback receives connection capability and is trusted server code; never caller/provider supplied. Error after update MUST escape connection context so rollback includes task result and lease expiry. No provider I/O inside transaction; no interpreting finish lease as permission for sending.

Before runtime acceptance execute on disposable PostgreSQL: expired/reacquired old owner cannot update; lease expiry between assert and finish causes rollback; update error rollback; success atomically transitions task+lease; competing owner and rowcount zero; connection/process restart durability. These are engineer-stage NOT_RUN in scaffold. Component unit tests only establish call protocol. Whole P02 claim/renew/recovery/worker fencing and D2 remain outside this task.

Recovery: disable consumer hook, restore backed-up shared hook bytes and remove only accepted new adapter/test/docs files; preserve task/journal data. Code rollback does not undo completed task transitions. Runtime/live activation requires its existing separate authorization.

## Обязательный worker hook: исключить обход fence

**Текущий worker.run_once без изменения подключать запрещено.** В нём broad except вокруг job+complete вызывает old fail_task; ControlBlocked вызывает old defer_task. После ошибки run_owned_transition это способно записать состояние чужого нового поколения без lease guard. Component PASS не закрывает этот дефект worker.

До любого запуска job интегратор обязан получить owner_token и generation из принятого claim/lease протокола для именно этой task_id. Это не поля произвольного payload. Отсутствующий/неподтверждённый transport → BLOCKED до job и ноль terminal writes. Нельзя создавать новый token, подставлять generation=1 либо читать текущего нового владельца и выдавать его за прежнего. Claim/renew/recovery остаются отдельными ещё не подключёнными зависимостями; F132 не создаёт их.

Все success/fail/defer terminal transitions проходят одну и ту же caller-owned transaction boundary с точным исходным owner/generation. Ownership/DB transaction errors классифицирует отдельный integration owner по accepted exceptions; они обязаны выйти к supervisor. Нельзя превращать их в обычную job failure, вызывать после них old complete_task/fail_task/defer_task, делать retry чужого terminal write или ставить новое поколение. В частности, окончательная owned finalization находится **за пределами** job exception handler.

Нормативный control-flow pseudocode интегратора (имена claim/dispatcher/classifier — prerequisites, не существующие runtime API):

```python
claimed = accepted_claim_and_transport()   # prerequisite: not implemented by F132
owner = require_exact_claim_owner(claimed)  # missing => BLOCKED before job
# Verify accepted ownership before job; no SQL tx spans provider/job I/O.
assert_current_owned_before_job(owner)
try:
    payload = process_job(claimed.task)
except OWNERSHIP_OR_DB_TRANSACTION_ERRORS:
    raise  # supervisor only; zero legacy writes
except sales_store.ControlBlocked as exc:
    transition, value = 'defer', safe_reason(exc)
except Exception as exc:
    transition, value = 'fail', safe_reason(exc)
else:
    transition, value = 'finish', payload

# Intentionally OUTSIDE try/except around job.
with postgres_store.connect() as conn:
    with conn.transaction():
        row = run_owned_transition(
            conn, lease_store, task_id=claimed.task_id,
            owner_token=owner.owner_token, generation=owner.generation,
            transition=transition,
            update=reviewed_sql_callback(transition, value),
        )
# Any assert/update/finish/commit/connection exception escapes.
# NO catch here calls unfenced task_store methods, alerts or another terminal write.
return row
```

`OWNERSHIP_OR_DB_TRANSACTION_ERRORS`, accepted claim/transport and reviewed_sql_callback must be replaced with reviewed concrete types/functions before merge; this pseudocode is not runnable code or evidence they exist. Generic external job failures may select fail; database/ownership errors must not fall into that generic category. Callback uses original task SQL semantics and same passed conn, original task_id/RUNNING predicate, RETURNING/zero-row conflict guard. Establish lease→task lock order consistently in claim/renew/recovery before connecting any branch. Finalization errors must remain observable to supervisor, without printing secrets.

## Дополнительные обязательные integration acceptance vectors H2

1. Old generation runs job; lease expires/reacquired before finish: finalization raises STALE_OWNER, **zero legacy writes**, no overwrite of new generation task/result.
2. Same race for job-failure→fail and ControlBlocked→defer: each uses original owner/generation, stale raises; no decrement/retry/backoff write to new owner.
3. Missing owner token/generation or task-key mismatch: BLOCKED before job, zero job calls, zero terminal/legacy writes.
4. SQL callback fails or zero-row conflict; finish_owned_in_tx fails after callback; commit/connection fails: error escapes terminal boundary, caller rollback where applicable; zero legacy fallback and no success acknowledgement.
5. Ordinary job failure while owner still valid: one owned fail callback with unchanged attempts/backoff; ordinary ControlBlocked: one owned defer callback with unchanged decrement/delay. Success: one owned finish callback.
6. Broad outer supervisor catches must log/report the failure without any unfenced task mutation, acquiring a fresh token, or using another generation to finish the old job.

Synthetic control-flow spies can prove call counts/branch separation only. PostgreSQL transactional rollback, concurrent generations, lock order and durable restart remain mandatory separate engineer-stage tests, NOT_RUN in this package. No new claim semantics, snapshot D2, provider actions or production changes are authorised by H2.
