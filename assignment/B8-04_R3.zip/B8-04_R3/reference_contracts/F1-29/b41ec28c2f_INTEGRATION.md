# Инженеру внедрения

В actual sales_manager.process_discover оставить assert_discovery_response_scope и ветку EXHAUSTED. После FOUND/lead dict guard, до sales_store.ingest_lead(lead_data), инженер вставляет qualify_and_ingest. Existing provider lead_data НЕ является FIRST_DISCOVERY_CANDIDATE_V1: отдельный reviewed mapper должен дать candidate, без выдуманного candidate_id или доказательств. Trusted policy/binding и resolve_assessment предоставляются сервером, не response/task flags. Эти mapper/resolvers ещё NOT_CONNECTED.

Интеграционный ingest closure принимает (candidate, *, qualification) и вызывает existing sales_store.ingest_lead с уже проверенным original lead_data (campaign_id назначен как сейчас); qualification не добавлять несуществующим DB полям. При nonqualified результатах не возвращать FOUND и не отмечать market exhausted: продолжить existing bounded candidate loop; поведение полного исчерпания review cases требует отдельного reviewed integration decision. DuplicateLead исключение идёт unchanged в существующий except, duplicate_count сохраняется. Adapter не выполняет сам sales_store import.

Перед merge проверить fresh SHA references относительно SOURCE. Подключение и E2E/DB проверки выполняет инженер отдельно. Rollback: сначала отключить consumer hook, затем удалить только новый module; frozen deps и существующие задачи не менять. Все current package tests — offline component, E2E/PG/live NOT_RUN.

Точный mapping для reviewed closure: candidate.runtime_campaign_id → lead_data.campaign_id; candidate.company_name → company_name; candidate.contact_email → email (F110 result.contact_email нормализован); candidate.source_url → source_url; qualification.source_observed_at → source_observed_at. Accepted sales_rules.validate_ingest и fingerprints должны пройти перед ingest. candidate_id нельзя превращать в lead_id: existing ingest сам создаёт UUID. Domain/contact_name/contact_role/phone/aliases/metadata допускаются только из отдельно проверенного original lead_data, не синтезируются; missing required input → blocked без ingest. Сравнить mapped campaign/company/email/source с qualified candidate; mismatch → blocked. Наличие trusted mapping и server source подтверждает интегратор отдельно: пакет не runtime ready. Frozen sales_store.py/sales_rules.py приложены для чтения API, не импортировать их в unit tests (их зависимости здесь не поставляются).

## Исправленная передача H2 (technical ABI R1)
Прямое подключение F128 projection к F129 binding запрещено: F112 возвращает 18 полей FIRST_CAMPAIGN_PROJECTION_V1, F110 принимает ровно пять полей FIRST_QUALIFICATION_BINDING_V1. Инженер внедрения владеет механическим mapper reference/qualification_binding_mapper.py: schema_version заменяется на FIRST_QUALIFICATION_BINDING_V1, а client_id/runtime_campaign_id/offer_id/binding_version копируются без преобразований. Остальная projection сохраняется для других consumers; её не обрезать in-place. Новый кандидатский adapter API не меняется.

```python
projection = resolve_campaign_projection(campaign, resolve_config=trusted_config_resolver, now=now)
qualification_binding = projection_to_qualification_binding(projection)
result = qualify_and_ingest(candidate, binding=qualification_binding, policy=trusted_policy,
    resolve_assessment=trusted_assessment_resolver, ingest=reviewed_ingest_closure, now=now)
```
Код mapper поставлен как frozen integration-owner reference, не задание кандидату и не изменение accepted F110/F112. tests/test_integration_mapping.py доказывает actual F112→mapper→actual F110; внешний control proof отдельно проверяет ту же цепь через candidate ABI с контрольными реализациями. Scaffolds в пакете намеренно остаются RED.

F128 projection НЕ содержит raw approved_facts с текстами/source_ref и полного offer. F130 должен получать исходный trusted F105 config отдельно через серверный resolver из того же authoritative campaign/binding_version, а не реконструировать config из projection. Никаких task-payload fallback или выдуманных фактов. Источник config, candidate identity, assessment/policy producers ещё не подключены. Пакет остаётся PREPARED_NOT_ISSUED, integration NOT_CONNECTED.
