-- REFERENCE ONLY. NOT APPLIED. PostgreSQL syntax, no extension dependency.
-- first_handoff_ref_r1 is a design namespace, NOT a reserved deployment name.
-- No IF NOT EXISTS: a real migration must fail on unexpected pre-existing objects.
-- Roles/grants, migration number and database are deliberately NOT invented.
BEGIN;
CREATE SCHEMA first_handoff_ref_r1;

CREATE TABLE first_handoff_ref_r1.authorities (
 authority_id uuid PRIMARY KEY,
 client_id text NOT NULL CHECK (length(client_id) BETWEEN 1 AND 128),
 runtime_campaign_id uuid NOT NULL,
 lead_id text NOT NULL CHECK (length(lead_id) BETWEEN 1 AND 128),
 mailbox_ref text NOT NULL CHECK (length(mailbox_ref) BETWEEN 1 AND 128),
 thread_id text NOT NULL CHECK (length(thread_id) BETWEEN 1 AND 128),
 current_revision bigint NOT NULL CHECK (current_revision >= 0),
 created_at timestamptz NOT NULL DEFAULT transaction_timestamp(),
 UNIQUE(client_id,runtime_campaign_id,lead_id,mailbox_ref,thread_id)
);

CREATE TABLE first_handoff_ref_r1.trust_versions (
 authority_id uuid NOT NULL REFERENCES first_handoff_ref_r1.authorities,
 trust_id uuid NOT NULL,
 source_ref text NOT NULL CHECK (length(source_ref) BETWEEN 1 AND 128),
 source_version text NOT NULL CHECK (length(source_version) BETWEEN 1 AND 128),
 kind text NOT NULL CHECK (kind IN ('BINDING','POLICY','LANGUAGE','FACTS','MATERIALS','RECIPIENT_APPROVAL','INTEREST_EVIDENCE')),
 payload jsonb NOT NULL CHECK (jsonb_typeof(payload)='object'),
 observed_at timestamptz NOT NULL DEFAULT transaction_timestamp(),
 source_recorded_at timestamptz,
 validity_mode text NOT NULL CHECK (validity_mode IN ('EXPIRING','NON_EXPIRING','UNKNOWN')),
 valid_until timestamptz,
 revoked boolean NOT NULL,
 PRIMARY KEY(authority_id,trust_id),
 UNIQUE(authority_id,kind,source_ref,source_version),
 CHECK ((validity_mode='EXPIRING' AND valid_until IS NOT NULL) OR
        (validity_mode IN ('NON_EXPIRING','UNKNOWN') AND valid_until IS NULL))
);

CREATE TABLE first_handoff_ref_r1.ingestion_checkpoints (
 authority_id uuid NOT NULL REFERENCES first_handoff_ref_r1.authorities,
 checkpoint_id uuid NOT NULL,
 source_ref text NOT NULL CHECK (length(source_ref) BETWEEN 1 AND 128),
 source_version text NOT NULL CHECK (length(source_version) BETWEEN 1 AND 128),
 coverage jsonb NOT NULL CHECK (jsonb_typeof(coverage)='object'),
 status text NOT NULL CHECK (status IN ('COMPLETE_TO_CUT','INCOMPLETE','UNKNOWN')),
 recorded_at timestamptz NOT NULL DEFAULT transaction_timestamp(),
 PRIMARY KEY(authority_id,checkpoint_id),
 UNIQUE(authority_id,source_ref,source_version)
);

CREATE TABLE first_handoff_ref_r1.authority_revisions (
 authority_id uuid NOT NULL REFERENCES first_handoff_ref_r1.authorities,
 revision bigint NOT NULL CHECK(revision >= 0),
 ownership text NOT NULL CHECK (ownership IN ('AUTOMATION','HUMAN','STOPPED')),
 campaign_status text NOT NULL CHECK (campaign_status IN ('RUNNING','PAUSED','EXHAUSTED')),
 emergency_stop boolean NOT NULL,
 opted_out boolean NOT NULL,
 checkpoint_id uuid,
 recorded_at timestamptz NOT NULL DEFAULT transaction_timestamp(),
 PRIMARY KEY(authority_id,revision),
 FOREIGN KEY(authority_id,checkpoint_id) REFERENCES first_handoff_ref_r1.ingestion_checkpoints(authority_id,checkpoint_id)
);
ALTER TABLE first_handoff_ref_r1.authorities ADD CONSTRAINT current_revision_exists
 FOREIGN KEY(authority_id,current_revision) REFERENCES first_handoff_ref_r1.authority_revisions(authority_id,revision)
 DEFERRABLE INITIALLY DEFERRED;

CREATE TABLE first_handoff_ref_r1.revision_dependencies (
 authority_id uuid NOT NULL,
 revision bigint NOT NULL,
 role text NOT NULL CHECK (role IN ('BINDING','POLICY','LANGUAGE','FACTS','MATERIALS','RECIPIENT_APPROVAL')),
 trust_id uuid NOT NULL,
 PRIMARY KEY(authority_id,revision,role),
 FOREIGN KEY(authority_id,revision) REFERENCES first_handoff_ref_r1.authority_revisions(authority_id,revision),
 FOREIGN KEY(authority_id,trust_id) REFERENCES first_handoff_ref_r1.trust_versions(authority_id,trust_id)
);

CREATE TABLE first_handoff_ref_r1.message_versions (
 authority_id uuid NOT NULL,
 message_id text NOT NULL CHECK(length(message_id) BETWEEN 1 AND 128),
 message_version bigint NOT NULL CHECK(message_version >= 1),
 at_revision bigint NOT NULL CHECK(at_revision >= 0),
 sequence bigint NOT NULL CHECK(sequence BETWEEN 0 AND 1000000000),
 direction text NOT NULL CHECK(direction IN ('INBOUND','OUTBOUND')),
 actor text NOT NULL CHECK(actor IN ('BUYER','AUTOMATION','HUMAN')),
 body text NOT NULL CHECK(length(body)>0),
 fact_ids jsonb NOT NULL CHECK(jsonb_typeof(fact_ids)='array'),
 material_ids jsonb NOT NULL CHECK(jsonb_typeof(material_ids)='array'),
 source_ref text NOT NULL CHECK(length(source_ref) BETWEEN 1 AND 128),
 source_revision bigint NOT NULL CHECK(source_revision >= 0),
 delivery_evidence jsonb NOT NULL CHECK(jsonb_typeof(delivery_evidence)='object'),
 recorded_at timestamptz NOT NULL DEFAULT transaction_timestamp(),
 PRIMARY KEY(authority_id,message_id,message_version),
 UNIQUE(authority_id,message_id,at_revision),
 FOREIGN KEY(authority_id,at_revision) REFERENCES first_handoff_ref_r1.authority_revisions(authority_id,revision),
 CHECK((direction='INBOUND' AND actor='BUYER') OR
       (direction='OUTBOUND' AND actor IN ('AUTOMATION','HUMAN')))
);
CREATE INDEX history_cut_lookup ON first_handoff_ref_r1.message_versions(authority_id,message_id,at_revision DESC);

CREATE TABLE first_handoff_ref_r1.interest_occurrences (
 authority_id uuid NOT NULL,
 trigger_ref uuid NOT NULL,
 evidence_id uuid NOT NULL,
 decision_id text NOT NULL CHECK(length(decision_id) BETWEEN 1 AND 128),
 decision text NOT NULL CHECK(decision IN ('INTEREST','QUESTION','UNCERTAIN')),
 registered_revision bigint NOT NULL CHECK(registered_revision >= 0),
 reevaluation_basis_ref text CHECK(length(reevaluation_basis_ref) BETWEEN 1 AND 128),
 recorded_at timestamptz NOT NULL DEFAULT transaction_timestamp(),
 PRIMARY KEY(authority_id,trigger_ref),
 UNIQUE(authority_id,evidence_id,decision_id),
 FOREIGN KEY(authority_id,evidence_id) REFERENCES first_handoff_ref_r1.trust_versions(authority_id,trust_id),
 FOREIGN KEY(authority_id,registered_revision) REFERENCES first_handoff_ref_r1.authority_revisions(authority_id,revision)
);

CREATE TABLE first_handoff_ref_r1.handoff_snapshots (
 authority_id uuid NOT NULL,
 snapshot_id uuid NOT NULL,
 trigger_ref uuid NOT NULL,
 handoff_event_id uuid NOT NULL UNIQUE,
 state_revision bigint NOT NULL CHECK(state_revision >= 0),
 captured_at timestamptz NOT NULL DEFAULT transaction_timestamp(),
 valid_until timestamptz,
 history_total bigint NOT NULL CHECK(history_total >= 0),
 envelope jsonb NOT NULL CHECK(jsonb_typeof(envelope)='object'),
 canonical_bytes bytea NOT NULL CHECK(octet_length(canonical_bytes)>0),
 snapshot_sha256 text NOT NULL CHECK(snapshot_sha256 ~ '^[0-9a-f]{64}$'),
 PRIMARY KEY(authority_id,snapshot_id),
 UNIQUE(snapshot_id),
 UNIQUE(authority_id,trigger_ref),
 FOREIGN KEY(authority_id,trigger_ref) REFERENCES first_handoff_ref_r1.interest_occurrences(authority_id,trigger_ref),
 FOREIGN KEY(authority_id,state_revision) REFERENCES first_handoff_ref_r1.authority_revisions(authority_id,revision)
);
CREATE INDEX snapshots_by_revision ON first_handoff_ref_r1.handoff_snapshots(authority_id,state_revision);

-- Append-only immutable records. Owner/superuser bypass remains operationally
-- possible: use restricted repository writer privileges in a real deployment.
CREATE FUNCTION first_handoff_ref_r1.reject_mutation() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
 RAISE EXCEPTION 'IMMUTABLE_RECORD' USING ERRCODE='55000';
END;
$$;
CREATE TRIGGER immutable_trust BEFORE UPDATE OR DELETE ON first_handoff_ref_r1.trust_versions FOR EACH ROW EXECUTE FUNCTION first_handoff_ref_r1.reject_mutation();
CREATE TRIGGER immutable_checkpoint BEFORE UPDATE OR DELETE ON first_handoff_ref_r1.ingestion_checkpoints FOR EACH ROW EXECUTE FUNCTION first_handoff_ref_r1.reject_mutation();
CREATE TRIGGER immutable_revision BEFORE UPDATE OR DELETE ON first_handoff_ref_r1.authority_revisions FOR EACH ROW EXECUTE FUNCTION first_handoff_ref_r1.reject_mutation();
CREATE TRIGGER immutable_dependencies BEFORE UPDATE OR DELETE ON first_handoff_ref_r1.revision_dependencies FOR EACH ROW EXECUTE FUNCTION first_handoff_ref_r1.reject_mutation();
CREATE TRIGGER immutable_message BEFORE UPDATE OR DELETE ON first_handoff_ref_r1.message_versions FOR EACH ROW EXECUTE FUNCTION first_handoff_ref_r1.reject_mutation();
CREATE TRIGGER immutable_occurrence BEFORE UPDATE OR DELETE ON first_handoff_ref_r1.interest_occurrences FOR EACH ROW EXECUTE FUNCTION first_handoff_ref_r1.reject_mutation();
CREATE TRIGGER immutable_snapshot BEFORE UPDATE OR DELETE ON first_handoff_ref_r1.handoff_snapshots FOR EACH ROW EXECUTE FUNCTION first_handoff_ref_r1.reject_mutation();
CREATE TRIGGER no_delete_authority BEFORE DELETE ON first_handoff_ref_r1.authorities FOR EACH ROW EXECUTE FUNCTION first_handoff_ref_r1.reject_mutation();
CREATE FUNCTION first_handoff_ref_r1.advance_authority() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
 IF ROW(NEW.authority_id,NEW.client_id,NEW.runtime_campaign_id,NEW.lead_id,NEW.mailbox_ref,NEW.thread_id,NEW.created_at)
 IS DISTINCT FROM ROW(OLD.authority_id,OLD.client_id,OLD.runtime_campaign_id,OLD.lead_id,OLD.mailbox_ref,OLD.thread_id,OLD.created_at)
 OR NEW.current_revision <> OLD.current_revision + 1 THEN
  RAISE EXCEPTION 'INVALID_AUTHORITY_ADVANCE' USING ERRCODE='55000';
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER ordered_authority_update BEFORE UPDATE ON first_handoff_ref_r1.authorities FOR EACH ROW EXECUTE FUNCTION first_handoff_ref_r1.advance_authority();
-- Seal historical cuts against later INSERT as well as UPDATE/DELETE.
CREATE FUNCTION first_handoff_ref_r1.require_open_revision() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE r bigint; proposed bigint;
BEGIN
 SELECT current_revision INTO r FROM first_handoff_ref_r1.authorities
 WHERE authority_id=NEW.authority_id FOR UPDATE;
 proposed := (to_jsonb(NEW)->>TG_ARGV[0])::bigint;
 IF r IS NULL OR proposed <> r+1 THEN
  RAISE EXCEPTION 'REVISION_NOT_OPEN' USING ERRCODE='55000';
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER dependencies_only_open BEFORE INSERT ON first_handoff_ref_r1.revision_dependencies FOR EACH ROW EXECUTE FUNCTION first_handoff_ref_r1.require_open_revision('revision');
CREATE TRIGGER messages_only_open BEFORE INSERT ON first_handoff_ref_r1.message_versions FOR EACH ROW EXECUTE FUNCTION first_handoff_ref_r1.require_open_revision('at_revision');
CREATE TRIGGER occurrences_only_open BEFORE INSERT ON first_handoff_ref_r1.interest_occurrences FOR EACH ROW EXECUTE FUNCTION first_handoff_ref_r1.require_open_revision('registered_revision');
-- authority_revisions itself is immutable; creation of future/orphan revisions
-- is prohibited by repository protocol, not fully checked by this reference DDL.
-- No relational membership rows can be appended to published snapshots:
-- complete membership is included in the single immutable envelope/bytes row.
COMMIT;
-- No DROP/rollback SQL. Reference design must not be applied by generic migrate.py.
