"""Internal D1 capture mechanics with a controlled test-source decoder.

No production decoder, authority activation, journal, dispatch or D2 permission.
Only EXPIRING immutable dependencies are supported by this bounded stage.
"""
import copy
import hashlib
import json
import uuid
from datetime import timezone
from psycopg import sql
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb
from .storage import HistoryRepository, SCOPE, _scope, _identifier, _json
import sales_first_handoff
import sales_handoff_intent

ROLES=('BINDING','POLICY','LANGUAGE','FACTS','MATERIALS','RECIPIENT_APPROVAL')
SEMANTIC={'binding','policy','language','facts','materials','recipient_ref','summary','next_step','reason'}
ENVELOPE={'schema_version','snapshot_id','scope','handoff_event_id','trigger_ref','state_revision','binding_version','captured_at','valid_until','context','recipient','interest','provenance','snapshot_sha256'}

def canonical(value):
    _json(value)
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')

def strict_load(raw):
    def pairs(items):
        result={}
        for k,v in items:
            if k in result:raise ValueError('duplicate JSON key')
            result[k]=v
        return result
    def constant(value):raise ValueError('nonfinite JSON')
    result=json.loads(bytes(raw).decode('utf-8'),object_pairs_hook=pairs,parse_constant=constant)
    _json(result)
    return result

def timestamp(value):return value.astimezone(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%fZ')

def trust_identity(row):
    return ('trust',str(row['authority_id']),str(row['trust_id']),row['kind'],row['source_ref'],row['source_version'])

def message_identity(row):
    return ('message',str(row['authority_id']),row['message_id'],row['message_version'],row['source_ref'],row['source_revision'])

def member(row):
    return {'identity':list(message_identity(row)),'sequence':row['sequence'],
            'body_sha256':hashlib.sha256(row['body'].encode('utf-8')).hexdigest()}

class SnapshotRepository(HistoryRepository):
    def __init__(self,*,connect_factory,schema,fixture_decoder):
        super().__init__(connect_factory=connect_factory,schema=schema)
        self._decoder=fixture_decoder

    def _bundle(self,c,a,trigger_ref,revision):
        aid=a['authority_id']
        occurrence=self._row(c,sql.SQL('SELECT * FROM {} WHERE authority_id=%s AND trigger_ref=%s').format(self._table('interest_occurrences')),[aid,trigger_ref])
        state=self._row(c,sql.SQL('SELECT * FROM {} WHERE authority_id=%s AND revision=%s').format(self._table('authority_revisions')),[aid,revision])
        if occurrence is None or state is None or occurrence['registered_revision']>revision:
            raise ValueError('unknown occurrence or revision')
        if (state['ownership'],state['campaign_status'],state['emergency_stop'],state['opted_out'])!=('AUTOMATION','RUNNING',False,False):
            raise ValueError('capture state blocked')
        checkpoint=self._row(c,sql.SQL('SELECT * FROM {} WHERE authority_id=%s AND checkpoint_id=%s').format(self._table('ingestion_checkpoints')),[aid,state['checkpoint_id']])
        if checkpoint is None or checkpoint['status']!='COMPLETE_TO_CUT':
            raise ValueError('coverage unavailable')
        with c.cursor(row_factory=dict_row) as cur:
            cur.execute(sql.SQL('SELECT d.role,t.* FROM {} d JOIN {} t ON (t.authority_id,t.trust_id)=(d.authority_id,d.trust_id) WHERE d.authority_id=%s AND d.revision=%s').format(self._table('revision_dependencies'),self._table('trust_versions')),[aid,revision]);rows=cur.fetchall()
        if len(rows)!=6 or {r['role'] for r in rows}!=set(ROLES) or any(r['kind']!=r['role'] for r in rows):
            raise ValueError('incomplete or mismatched dependency roles')
        sources={r['role']:dict(r) for r in rows}
        evidence=self._row(c,sql.SQL('SELECT * FROM {} WHERE authority_id=%s AND trust_id=%s').format(self._table('trust_versions')),[aid,occurrence['evidence_id']])
        if evidence is None or evidence['kind']!='INTEREST_EVIDENCE':raise ValueError('invalid interest source')
        sources['INTEREST_EVIDENCE']=evidence
        for row in sources.values():
            if row['authority_id']!=aid or row['validity_mode']!='EXPIRING' or row['valid_until'] is None or row['revoked'] is not False:
                raise ValueError('unsupported or revoked validity')
        history=self._history(c,aid,revision)
        return {'authority':a,'state':state,'occurrence':occurrence,'checkpoint':checkpoint,'sources':sources,'history':history}

    def _ref(self,identity,seen):
        ref=self._decoder.encode_reference(identity)
        _identifier(ref)
        decoded=self._decoder.decode_reference(ref)
        if type(decoded) is not tuple or canonical(list(decoded))!=canonical(list(identity)):raise ValueError('reference identity mismatch')
        prior=seen.get(ref)
        if prior is not None and canonical(list(prior))!=canonical(list(identity)):raise ValueError('reference alias')
        seen[ref]=identity
        return ref

    def _inputs(self,bundle,event_id):
        # Never let a decoder mutate the real queried rows used by checks.
        decoded=self._decoder.decode_sources(copy.deepcopy(bundle))
        if type(decoded) is not dict or set(decoded)!=SEMANTIC:raise ValueError('unexpected decoded fields')
        _json(decoded)
        if type(decoded['binding']) is not dict or set(decoded['binding'])!={'offer'} or type(decoded['binding']['offer']) is not dict or set(decoded['binding']['offer'])!={'offer_id'}:
            raise ValueError('invalid decoded binding')
        if type(decoded['policy']) is not dict or set(decoded['policy'])!={'policy_version'}:raise ValueError('invalid decoded policy')
        if type(decoded['language']) is not dict or set(decoded['language'])!={'locale','language_pack_version','language_packs'}:raise ValueError('invalid decoded language')
        coverage=self._decoder.decode_coverage(copy.deepcopy(bundle['checkpoint']),copy.deepcopy(bundle))
        if type(coverage) is not dict or set(coverage)!={'members','pending','quarantined','outbound'}:raise ValueError('unexpected coverage fields')
        _json(coverage)
        expected=[member(r) for r in bundle['history']]
        expected_out=[{'identity':list(message_identity(r)),'delivery_evidence':r['delivery_evidence']} for r in bundle['history'] if r['direction']=='OUTBOUND']
        if canonical(coverage['members'])!=canonical(expected) or coverage['pending']!=[] or coverage['quarantined']!=[] or canonical(coverage['outbound'])!=canonical(expected_out):
            raise ValueError('incomplete or mismatched coverage')
        a=bundle['authority'];state=bundle['state'];sources=bundle['sources'];o=bundle['occurrence'];aid=str(a['authority_id']);revision=state['revision'];seen={}
        scope={k:(str(a[k]) if k=='runtime_campaign_id' else a[k]) for k in SCOPE};_scope(scope)
        history=[]
        for row in bundle['history']:
            history.append({**scope,**{k:row[k] for k in ('message_id','sequence','direction','actor','body','fact_ids','material_ids')}})
        context={'schema_version':'FIRST_HANDOFF_INPUT_V1',**scope,'handoff_event_id':event_id,
                 'product_id':decoded['binding']['offer']['offer_id'],'policy_version':decoded['policy']['policy_version'],
                 **decoded['language'],'status':'ACTIVE','reason':decoded['reason'],'summary':decoded['summary'],
                 'next_step':decoded['next_step'],'history':history,'facts':decoded['facts'],'materials':decoded['materials']}
        recipient_ref=self._ref(trust_identity(sources['RECIPIENT_APPROVAL']),seen)
        interest_ref=self._ref(trust_identity(sources['INTEREST_EVIDENCE']),seen)
        recipient={'schema_version':'FIRST_HANDOFF_RECIPIENT_V1','client_id':scope['client_id'],'runtime_campaign_id':scope['runtime_campaign_id'],'recipient_ref':decoded['recipient_ref'],'approval_ref':recipient_ref}
        interest={'schema_version':'FIRST_INTEREST_EVIDENCE_V1','client_id':scope['client_id'],'runtime_campaign_id':scope['runtime_campaign_id'],'lead_id':scope['lead_id'],'decision':o['decision'],'evidence_ref':interest_ref}
        # Both actual components run, including malformed QUESTION/UNCERTAIN contexts.
        sales_first_handoff.assemble_handoff_context(context)
        sales_handoff_intent.build_handoff_intent(context,recipient,interest)
        provenance={'authority_ref':self._ref(('authority',aid,revision,str(bundle['checkpoint']['checkpoint_id'])),seen),
            'binding_ref':self._ref(trust_identity(sources['BINDING']),seen),'recipient_approval_ref':recipient_ref,
            'interest_evidence_ref':interest_ref,'history_cut_revision':revision,'history_total':len(history),
            'history_sources':[{'message_id':r['message_id'],'record_ref':self._ref(message_identity(r),seen),'record_revision':r['source_revision'],'body_sha256':hashlib.sha256(r['body'].encode('utf-8')).hexdigest()} for r in bundle['history']],
            'facts_ref':self._ref(trust_identity(sources['FACTS']),seen),'materials_ref':self._ref(trust_identity(sources['MATERIALS']),seen),
            'outbound_evidence_ref':self._ref(('outbound',aid,revision,str(bundle['checkpoint']['checkpoint_id'])),seen) if expected_out else None}
        return scope,context,recipient,interest,provenance

    def _envelope(self,bundle,snapshot_id,event_id,captured_at,inputs=None):
        scope,context,recipient,interest,provenance=inputs if inputs is not None else self._inputs(bundle,event_id)
        deadline=min(r['valid_until'] for r in bundle['sources'].values())
        if deadline<=captured_at:raise ValueError('expired evidence at capture')
        result={'schema_version':'FIRST_HANDOFF_SNAPSHOT_V1','snapshot_id':snapshot_id,'scope':scope,'handoff_event_id':event_id,
            'trigger_ref':str(bundle['occurrence']['trigger_ref']),'state_revision':bundle['state']['revision'],
            'binding_version':bundle['sources']['BINDING']['source_version'],'captured_at':timestamp(captured_at),'valid_until':timestamp(deadline),
            'context':context,'recipient':recipient,'interest':interest,'provenance':provenance}
        raw=canonical(result);result['snapshot_sha256']=hashlib.sha256(raw).hexdigest()
        return result,raw,deadline

    def _verify(self,c,a,row):
        envelope=strict_load(row['canonical_bytes'])
        if type(envelope) is not dict or set(envelope)!=ENVELOPE-{'snapshot_sha256'}:raise ValueError('invalid canonical envelope')
        raw=bytes(row['canonical_bytes']);digest=hashlib.sha256(raw).hexdigest()
        if canonical(envelope)!=raw or row['snapshot_sha256']!=digest:raise ValueError('snapshot byte/hash mismatch')
        full={**envelope,'snapshot_sha256':digest}
        if canonical(row['envelope'])!=canonical(full):raise ValueError('snapshot display mismatch')
        if row['authority_id']!=a['authority_id']:raise ValueError('snapshot scope mismatch')
        checks={'snapshot_id':str(row['snapshot_id']),'handoff_event_id':str(row['handoff_event_id']),'trigger_ref':str(row['trigger_ref']),
                'state_revision':row['state_revision'],'captured_at':timestamp(row['captured_at']),'valid_until':timestamp(row['valid_until']) if row['valid_until'] is not None else None}
        for k,v in checks.items():
            if canonical(envelope[k])!=canonical(v):raise ValueError('snapshot column mismatch')
        bundle=self._bundle(c,a,str(row['trigger_ref']),row['state_revision'])
        expected,expected_raw,_=self._envelope(bundle,str(row['snapshot_id']),str(row['handoff_event_id']),row['captured_at'])
        if row['history_total']!=len(bundle['history']) or expected_raw!=raw or canonical(expected)!=canonical(full):raise ValueError('snapshot provenance/content mismatch')
        return full

    def load_or_capture(self,*,scope,trigger_ref):
        _scope(scope);trigger_ref=self._uuid_key(trigger_ref)
        with self.connect_factory() as c:
            with c.transaction():
                a=self._locked_scope(c,scope)
                existing=self._row(c,sql.SQL('SELECT * FROM {} WHERE authority_id=%s AND trigger_ref=%s').format(self._table('handoff_snapshots')),[a['authority_id'],trigger_ref])
                if existing is not None:return self._verify(c,a,existing)
                bundle=self._bundle(c,a,trigger_ref,a['current_revision'])
                snapshot_id=str(uuid.uuid4());event_id=str(uuid.uuid4());inputs=self._inputs(bundle,event_id)
                captured_at=c.execute('SELECT clock_timestamp()').fetchone()[0]
                envelope,raw,deadline=self._envelope(bundle,snapshot_id,event_id,captured_at,inputs)
                self._row(c,sql.SQL('INSERT INTO {} (authority_id,snapshot_id,trigger_ref,handoff_event_id,state_revision,captured_at,valid_until,history_total,envelope,canonical_bytes,snapshot_sha256) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING *').format(self._table('handoff_snapshots')),
                          [a['authority_id'],snapshot_id,trigger_ref,event_id,a['current_revision'],captured_at,deadline,len(bundle['history']),Jsonb(envelope),raw,envelope['snapshot_sha256']])
        return envelope

    def get(self,*,scope,handoff_event_id):
        _scope(scope);handoff_event_id=self._uuid_key(handoff_event_id)
        with self.connect_factory() as c:
            with c.transaction():
                a=self._locked_scope(c,scope)
                row=self._row(c,sql.SQL('SELECT * FROM {} WHERE authority_id=%s AND handoff_event_id=%s').format(self._table('handoff_snapshots')),[a['authority_id'],handoff_event_id])
                return None if row is None else self._verify(c,a,row)
