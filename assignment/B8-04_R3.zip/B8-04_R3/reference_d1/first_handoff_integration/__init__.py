"""Staged D1 mechanical persistence only; no capture or runtime hookup."""
