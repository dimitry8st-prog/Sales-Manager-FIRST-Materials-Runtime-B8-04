"""D1 mechanical history/source-metadata persistence. Internal staging API, not shared ABI.

No snapshot capture, trust assertion, activation, provider or journal interface.
Imported source metadata stays unattached; occurrence publication is blocked-state only.
Schema and connection factory must be explicitly injected by the integrator.
Only stopped/paused/emergency-stopped authorities may append through this API.
"""
import json
import math
import re
import uuid
from psycopg import sql
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

SCOPE = ('client_id', 'runtime_campaign_id', 'lead_id', 'mailbox_ref', 'thread_id')
MESSAGE = ('message_id','sequence','direction','actor','body','fact_ids','material_ids',
           'source_ref','source_revision','delivery_evidence')


def _json(value):
    """Reject JSON coercions; no source authenticity is asserted by this check."""
    if value is None or type(value) in (bool,int): return
    if type(value) is float:
        if not math.isfinite(value): raise ValueError('invalid JSON number')
        return
    if type(value) is str:
        if '\x00' in value: raise ValueError('invalid JSON string')
        value.encode('utf-8');return
    if type(value) is list:
        for item in value: _json(item)
        return
    if type(value) is dict:
        for k,v in value.items():
            if type(k) is not str: raise ValueError('invalid JSON key')
            _json(k);_json(v)
        return
    raise ValueError('invalid JSON type')


def _identifier(value):
    # Exact frozen F114 ID semantics; D1 requires non-null thread_id.
    if type(value) is not str or not 1 <= len(value) <= 128 or value != value.strip():
        raise ValueError('invalid identifier')
    if any(ord(c) < 32 or ord(c) == 127 for c in value):
        raise ValueError('invalid identifier')
    value.encode('utf-8')


def _scope(value):
    if type(value) is not dict or set(value) != set(SCOPE):
        raise ValueError('invalid scope')
    for k in SCOPE:
        _identifier(value[k])
    v=value['runtime_campaign_id']
    if re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',v) is None or str(uuid.UUID(v))!=v:
        raise ValueError('invalid campaign UUID')


def _message(m):
    if type(m) is not dict or set(m)!=set(MESSAGE):
        raise ValueError('invalid message')
    _identifier(m['message_id']);_identifier(m['source_ref'])
    for k in ('sequence','source_revision'):
        if type(m[k]) is not int or not 0 <= m[k] <= (1000000000 if k=='sequence' else 9223372036854775807):
            raise ValueError('invalid sequence/revision')
    if (m['direction'],m['actor']) not in (('INBOUND','BUYER'),('OUTBOUND','AUTOMATION'),('OUTBOUND','HUMAN')):
        raise ValueError('invalid direction/actor')
    if type(m['body']) is not str or not m['body'] or '\x00' in m['body']:
        raise ValueError('invalid body')
    m['body'].encode('utf-8')  # Preserve oversized bodies; frozen capture limits are separate.
    for k in ('fact_ids','material_ids'):
        if type(m[k]) is not list: raise ValueError('invalid references')
        for v in m[k]: _identifier(v)
        if len(set(m[k]))!=len(m[k]): raise ValueError('duplicate references')
    if type(m['delivery_evidence']) is not dict: raise ValueError('invalid delivery evidence')
    _json(m['delivery_evidence'])
    json.dumps(m['delivery_evidence'],allow_nan=False).encode('utf-8')


class HistoryRepository:
    def __init__(self, *, connect_factory, schema):
        if not callable(connect_factory) or type(schema) is not str or re.fullmatch(r'[a-z][a-z0-9_]{0,62}',schema) is None:
            raise ValueError('invalid repository configuration')
        self.connect_factory=connect_factory
        self.schema=schema

    def _table(self,name):
        return sql.Identifier(self.schema,name)

    def _authority(self,c,scope,lock=False):
        q=sql.SQL('SELECT * FROM {} WHERE '+ ' AND '.join(k+'=%s' for k in SCOPE)+(' FOR UPDATE' if lock else '')).format(self._table('authorities'))
        with c.cursor(row_factory=dict_row) as cur:
            cur.execute(q,[scope[k] for k in SCOPE]);return cur.fetchone()

    def initialize(self, *, scope):
        _scope(scope)
        # Conflict waits for concurrent initializer; following statement reads committed row.
        with self.connect_factory() as c:
            with c.transaction():
                c.execute('SET TRANSACTION ISOLATION LEVEL READ COMMITTED')
                aid=uuid.uuid4()
                row=c.execute(sql.SQL('INSERT INTO {} (authority_id,client_id,runtime_campaign_id,lead_id,mailbox_ref,thread_id,current_revision) VALUES(%s,%s,%s,%s,%s,%s,0) ON CONFLICT (client_id,runtime_campaign_id,lead_id,mailbox_ref,thread_id) DO NOTHING RETURNING authority_id').format(self._table('authorities')),[aid,*[scope[k] for k in SCOPE]]).fetchone()
                if row:
                    c.execute(sql.SQL("INSERT INTO {}(authority_id,revision,ownership,campaign_status,emergency_stop,opted_out) VALUES(%s,0,'STOPPED','PAUSED',true,false)").format(self._table('authority_revisions')),[aid])
                a=self._authority(c,scope,True)
                if a is None: raise RuntimeError('authority initialization unconfirmed')
                # Corrupt/missing revision cannot be returned as initialized.
                exists=c.execute(sql.SQL('SELECT 1 FROM {} WHERE authority_id=%s AND revision=%s').format(self._table('authority_revisions')),[a['authority_id'],a['current_revision']]).fetchone()
                if not exists: raise RuntimeError('authority revision missing')
                result={'authority_id':str(a['authority_id']),'revision':a['current_revision']}
        return result

    def _history(self,c,aid,revision):
        with c.cursor(row_factory=dict_row) as cur:
            cur.execute(sql.SQL('SELECT * FROM (SELECT DISTINCT ON(message_id) * FROM {} WHERE authority_id=%s AND at_revision<=%s ORDER BY message_id,at_revision DESC) h ORDER BY sequence,message_id').format(self._table('message_versions')),[aid,revision])
            rows=cur.fetchall()
        if len({r['sequence'] for r in rows})!=len(rows): raise RuntimeError('duplicate active sequence')
        return rows

    def read_history(self, *, scope, revision):
        _scope(scope)
        if type(revision) is not int or revision<0: raise ValueError('invalid revision')
        with self.connect_factory() as c:
            with c.transaction():
                a=self._authority(c,scope,True)
                if a is None or revision>a['current_revision']: raise ValueError('unknown scope/revision')
                if not c.execute(sql.SQL('SELECT 1 FROM {} WHERE authority_id=%s AND revision=%s').format(self._table('authority_revisions')),[a['authority_id'],revision]).fetchone():
                    raise RuntimeError('authority revision missing')
                rows=self._history(c,a['authority_id'],revision)
        return rows

    def append_history(self, *, scope, expected_revision, messages):
        _scope(scope)
        if type(expected_revision) is not int or expected_revision<0 or type(messages) is not list or not messages:
            raise ValueError('invalid history publication')
        for m in messages: _message(m)
        if len({m['message_id'] for m in messages})!=len(messages): raise ValueError('duplicate message ID')
        with self.connect_factory() as c:
            with c.transaction():
                a=self._authority(c,scope,True)
                if a is None or a['current_revision']!=expected_revision: raise ValueError('revision mismatch')
                aid=a['authority_id']; rev=expected_revision+1
                with c.cursor(row_factory=dict_row) as cur:
                    cur.execute(sql.SQL('SELECT * FROM {} WHERE authority_id=%s AND revision=%s').format(self._table('authority_revisions')),[aid,expected_revision]);state=cur.fetchone()
                if state is None or (state['ownership'],state['campaign_status'],state['emergency_stop'],state['checkpoint_id'])!=('STOPPED','PAUSED',True,None):
                    raise ValueError('requires blocked mechanical authority')
                old={r['message_id']:r for r in self._history(c,aid,expected_revision)}
                for m in messages:
                    prior=old.get(m['message_id'])
                    if prior and (m['source_ref']!=prior['source_ref'] or m['sequence']!=prior['sequence'] or m['direction']!=prior['direction'] or m['actor']!=prior['actor']):
                        raise ValueError('immutable message source/order')
                merged={**old,**{m['message_id']:m for m in messages}}
                if len({m['sequence'] for m in merged.values()})!=len(merged): raise ValueError('duplicate active sequence')
                c.execute(sql.SQL('INSERT INTO {} (authority_id,revision,ownership,campaign_status,emergency_stop,opted_out,checkpoint_id) SELECT authority_id,%s,ownership,campaign_status,emergency_stop,opted_out,checkpoint_id FROM {} WHERE authority_id=%s AND revision=%s').format(self._table('authority_revisions'),self._table('authority_revisions')),[rev,aid,expected_revision])
                for m in messages:
                    values=[aid,m['message_id'],old.get(m['message_id'],{}).get('message_version',0)+1,rev,*[Jsonb(m[k]) if k in ('fact_ids','material_ids','delivery_evidence') else m[k] for k in MESSAGE[1:]]]
                    c.execute(sql.SQL('INSERT INTO {} (authority_id,message_id,message_version,at_revision,sequence,direction,actor,body,fact_ids,material_ids,source_ref,source_revision,delivery_evidence) VALUES('+','.join(['%s']*13)+')').format(self._table('message_versions')),values)
                c.execute(sql.SQL('UPDATE {} SET current_revision=%s WHERE authority_id=%s').format(self._table('authorities')),[rev,aid])
        return rev

    # Internal controlled-source staging methods, not an authenticated producer API.
    def _row(self, c, query, params):
        with c.cursor(row_factory=dict_row) as cur:
            cur.execute(query, params)
            return cur.fetchone()

    def _locked_scope(self, c, scope):
        a = self._authority(c, scope, True)
        if a is None:
            raise ValueError('unknown authority')
        return a

    def _metadata(self, record, fields, json_field):
        if type(record) is not dict or set(record) != set(fields):
            raise ValueError('invalid source metadata')
        _identifier(record['source_ref']); _identifier(record['source_version'])
        if type(record[json_field]) is not dict:
            raise ValueError('invalid source JSON object')
        _json(record[json_field])

    def store_trust(self, *, scope, record):
        """Retain immutable evidence; validity fields do not confer approval."""
        from datetime import datetime
        _scope(scope)
        fields = ('source_ref','source_version','kind','payload','source_recorded_at',
                  'validity_mode','valid_until','revoked')
        self._metadata(record, fields, 'payload')
        if type(record['kind']) is not str or record['kind'] not in (
            'BINDING','POLICY','LANGUAGE','FACTS','MATERIALS','RECIPIENT_APPROVAL','INTEREST_EVIDENCE'):
            raise ValueError('invalid trust kind')
        mode = record['validity_mode']
        if type(mode) is not str or mode not in ('EXPIRING','NON_EXPIRING','UNKNOWN'):
            raise ValueError('invalid validity mode')
        if type(record['revoked']) is not bool:
            raise ValueError('invalid revocation value')
        for name in ('source_recorded_at','valid_until'):
            value = record[name]
            if value is not None and (type(value) is not datetime or value.tzinfo is None or value.utcoffset() is None):
                raise ValueError('invalid source timestamp')
        if (mode == 'EXPIRING') != (record['valid_until'] is not None):
            raise ValueError('invalid validity metadata')
        with self.connect_factory() as c:
            with c.transaction():
                a = self._locked_scope(c, scope); aid = a['authority_id']
                table = self._table('trust_versions')
                row = self._row(c, sql.SQL('SELECT * FROM {} WHERE authority_id=%s AND kind=%s AND source_ref=%s AND source_version=%s').format(table),
                                [aid,record['kind'],record['source_ref'],record['source_version']])
                if row is not None:
                    equal = c.execute(sql.SQL('SELECT payload=%s::jsonb AND source_recorded_at IS NOT DISTINCT FROM %s::timestamptz AND validity_mode=%s AND valid_until IS NOT DISTINCT FROM %s::timestamptz AND revoked=%s FROM {} WHERE authority_id=%s AND trust_id=%s').format(table),
                                      [Jsonb(record['payload']),record['source_recorded_at'],mode,record['valid_until'],record['revoked'],aid,row['trust_id']]).fetchone()[0]
                    if not equal: raise ValueError('immutable trust conflict')
                    return row
                values = [aid,uuid.uuid4(),record['source_ref'],record['source_version'],record['kind'],Jsonb(record['payload']),record['source_recorded_at'],mode,record['valid_until'],record['revoked']]
                row = self._row(c, sql.SQL('INSERT INTO {} (authority_id,trust_id,source_ref,source_version,kind,payload,source_recorded_at,validity_mode,valid_until,revoked,observed_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,clock_timestamp()) RETURNING *').format(table), values)
        return row

    def read_trust(self, *, scope, trust_id):
        _scope(scope); trust_id = self._uuid_key(trust_id)
        with self.connect_factory() as c:
            with c.transaction():
                a = self._locked_scope(c, scope)
                return self._row(c, sql.SQL('SELECT * FROM {} WHERE authority_id=%s AND trust_id=%s').format(self._table('trust_versions')), [a['authority_id'],trust_id])

    def _uuid_key(self, value):
        if type(value) is not str or str(uuid.UUID(value)) != value:
            raise ValueError('invalid record UUID')
        return value

    def store_checkpoint(self, *, scope, record):
        """Store coverage assertions without certifying their producer or completeness."""
        _scope(scope)
        self._metadata(record, ('source_ref','source_version','coverage','status'), 'coverage')
        if type(record['status']) is not str or record['status'] not in ('COMPLETE_TO_CUT','INCOMPLETE','UNKNOWN'):
            raise ValueError('invalid coverage status')
        with self.connect_factory() as c:
            with c.transaction():
                a = self._locked_scope(c, scope); aid = a['authority_id']; table = self._table('ingestion_checkpoints')
                row = self._row(c, sql.SQL('SELECT * FROM {} WHERE authority_id=%s AND source_ref=%s AND source_version=%s').format(table), [aid,record['source_ref'],record['source_version']])
                if row is not None:
                    equal = c.execute(sql.SQL('SELECT coverage=%s::jsonb AND status=%s FROM {} WHERE authority_id=%s AND checkpoint_id=%s').format(table), [Jsonb(record['coverage']),record['status'],aid,row['checkpoint_id']]).fetchone()[0]
                    if not equal: raise ValueError('immutable checkpoint conflict')
                    return row
                row = self._row(c, sql.SQL('INSERT INTO {} (authority_id,checkpoint_id,source_ref,source_version,coverage,status,recorded_at) VALUES (%s,%s,%s,%s,%s,%s,clock_timestamp()) RETURNING *').format(table), [aid,uuid.uuid4(),record['source_ref'],record['source_version'],Jsonb(record['coverage']),record['status']])
        return row

    def read_checkpoint(self, *, scope, checkpoint_id):
        _scope(scope); checkpoint_id = self._uuid_key(checkpoint_id)
        with self.connect_factory() as c:
            with c.transaction():
                a = self._locked_scope(c, scope)
                return self._row(c, sql.SQL('SELECT * FROM {} WHERE authority_id=%s AND checkpoint_id=%s').format(self._table('ingestion_checkpoints')), [a['authority_id'],checkpoint_id])

    def register_occurrence(self, *, scope, expected_revision, evidence_id, decision_id, decision, reevaluation_basis_ref=None):
        """Controlled first assessment only; no reevaluation authorization is inferred."""
        _scope(scope); evidence_id = self._uuid_key(evidence_id); _identifier(decision_id)
        if type(expected_revision) is not int or expected_revision < 0:
            raise ValueError('invalid revision')
        if type(decision) is not str or decision not in ('INTEREST','QUESTION','UNCERTAIN'):
            raise ValueError('invalid assessment decision')
        if reevaluation_basis_ref is not None:
            raise ValueError('reevaluation outside mechanical boundary')
        with self.connect_factory() as c:
            with c.transaction():
                a = self._locked_scope(c, scope); aid = a['authority_id']; table = self._table('interest_occurrences')
                evidence = self._row(c, sql.SQL('SELECT kind FROM {} WHERE authority_id=%s AND trust_id=%s').format(self._table('trust_versions')), [aid,evidence_id])
                if evidence is None or evidence['kind'] != 'INTEREST_EVIDENCE':
                    raise ValueError('unknown scoped interest evidence')
                row = self._row(c, sql.SQL('SELECT * FROM {} WHERE authority_id=%s AND evidence_id=%s AND decision_id=%s').format(table), [aid,evidence_id,decision_id])
                if row is not None:
                    if row['decision'] != decision or row['reevaluation_basis_ref'] is not None:
                        raise ValueError('immutable assessment conflict')
                    return row
                if c.execute(sql.SQL('SELECT 1 FROM {} WHERE authority_id=%s AND evidence_id=%s').format(table), [aid,evidence_id]).fetchone():
                    raise ValueError('reevaluation outside mechanical boundary')
                if a['current_revision'] != expected_revision:
                    raise ValueError('revision mismatch')
                state = self._row(c, sql.SQL('SELECT * FROM {} WHERE authority_id=%s AND revision=%s').format(self._table('authority_revisions')), [aid,expected_revision])
                if state is None or (state['ownership'],state['campaign_status'],state['emergency_stop'],state['checkpoint_id']) != ('STOPPED','PAUSED',True,None):
                    raise ValueError('requires blocked mechanical authority')
                if c.execute(sql.SQL('SELECT 1 FROM {} WHERE authority_id=%s AND revision=%s LIMIT 1').format(self._table('revision_dependencies')), [aid,expected_revision]).fetchone():
                    raise ValueError('attached dependencies outside mechanical boundary')
                rev = expected_revision + 1
                c.execute(sql.SQL('INSERT INTO {} (authority_id,revision,ownership,campaign_status,emergency_stop,opted_out,checkpoint_id) SELECT authority_id,%s,ownership,campaign_status,emergency_stop,opted_out,checkpoint_id FROM {} WHERE authority_id=%s AND revision=%s').format(self._table('authority_revisions'),self._table('authority_revisions')), [rev,aid,expected_revision])
                row = self._row(c, sql.SQL('INSERT INTO {} (authority_id,trigger_ref,evidence_id,decision_id,decision,registered_revision,reevaluation_basis_ref,recorded_at) VALUES(%s,%s,%s,%s,%s,%s,NULL,clock_timestamp()) RETURNING *').format(table), [aid,uuid.uuid4(),evidence_id,decision_id,decision,rev])
                c.execute(sql.SQL('UPDATE {} SET current_revision=%s WHERE authority_id=%s').format(self._table('authorities')), [rev,aid])
        return row

    def read_occurrence(self, *, scope, trigger_ref):
        _scope(scope); trigger_ref = self._uuid_key(trigger_ref)
        with self.connect_factory() as c:
            with c.transaction():
                a = self._locked_scope(c, scope)
                return self._row(c, sql.SQL('SELECT * FROM {} WHERE authority_id=%s AND trigger_ref=%s').format(self._table('interest_occurrences')), [a['authority_id'],trigger_ref])
