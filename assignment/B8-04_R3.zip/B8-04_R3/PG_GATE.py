"""Real PostgreSQL transport/component gate, never a substitute for installed F1 dependency tests.
Candidate supplies solution/<module>/acceptance_pg.py only for adapter/SQL setup; production logic remains module.api.
"""
import argparse,hashlib,importlib,json,os,sys,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));from ACCEPTANCE_RUNNER import Ports,subset

def main():
 p=argparse.ArgumentParser();p.add_argument('--module',required=True);p.add_argument('--schema',required=True);p.add_argument('--phase',choices=['before_restart','after_restart'],required=True);a=p.parse_args()
 if len(a.schema)>50 or not a.schema.startswith('b8_accept_') or not a.schema.replace('_','').isalnum():p.error('isolated b8_accept_* schema required')
 dsn=os.environ.get('B8_TEST_DSN')
 if not dsn:print('NOT_RUN: B8_TEST_DSN required; credentials never printed');return 3
 try:import psycopg
 except ImportError:print('NOT_RUN: install psycopg in isolated test runtime');return 3
 sys.path.insert(0,str(ROOT/'solution'));sys.path.insert(0,str(ROOT/'reference_source'))
 try:m=importlib.import_module(a.module+'.acceptance_pg')
 except ModuleNotFoundError:print('NOT_IMPLEMENTED: candidate acceptance_pg adapter required');return 3
 def connect():return psycopg.connect(dsn)
 with connect() as c1,connect() as c2:
  assert c1.info.backend_pid!=c2.info.backend_pid
  c1.execute('CREATE SCHEMA IF NOT EXISTS '+a.schema)
  c1.execute('CREATE TABLE IF NOT EXISTS '+a.schema+'.harness_probe(k text primary key,v text not null)');c1.commit()
  if a.phase=='before_restart':
   c1.execute('DELETE FROM '+a.schema+'.harness_probe WHERE k=%s',('marker',));c1.commit()
   c1.execute('INSERT INTO '+a.schema+'.harness_probe VALUES (%s,%s) ON CONFLICT(k) DO UPDATE SET v=excluded.v',('marker','before_restart'))
   assert c2.execute('SELECT v FROM '+a.schema+'.harness_probe WHERE k=%s',('marker',)).fetchone() is None
   c2.rollback();c1.rollback()
   assert c2.execute('SELECT v FROM '+a.schema+'.harness_probe WHERE k=%s',('marker',)).fetchone() is None;c2.rollback()
   c1.execute('INSERT INTO '+a.schema+'.harness_probe VALUES (%s,%s) ON CONFLICT(k) DO UPDATE SET v=excluded.v',('marker','committed'))
   started=c1.execute('SELECT pg_postmaster_start_time()').fetchone()[0].isoformat()
   c1.execute('INSERT INTO '+a.schema+'.harness_probe VALUES (%s,%s) ON CONFLICT(k) DO UPDATE SET v=excluded.v',('postmaster_start',started));c1.commit()
   assert c2.execute('SELECT v FROM '+a.schema+'.harness_probe WHERE k=%s',('marker',)).fetchone()==('committed',);c2.rollback()
  else:
   assert c2.execute('SELECT v FROM '+a.schema+'.harness_probe WHERE k=%s',('marker',)).fetchone()==('committed',)
   from datetime import datetime
   old=c2.execute('SELECT v FROM '+a.schema+'.harness_probe WHERE k=%s',('postmaster_start',)).fetchone()
   assert old,'missing before_restart timestamp'
   current=c2.execute('SELECT pg_postmaster_start_time()').fetchone()[0]
   assert current>datetime.fromisoformat(old[0]),'server restart not verified; after_restart must follow actual isolated PostgreSQL restart'
 # Each fixture isolated below module schema; helper may adapt SQL storage, must never fake outcome/replay.
 executed=0
 for f in json.loads((ROOT/'acceptance/fixtures.json').read_text()):
  if 'repeat_expect' not in f or f.get('repeat_request_update'):continue
  executed+=1
  fixture_schema=a.schema+'_'+hashlib.sha256(f['name'].encode()).hexdigest()[:8]
  m.initialize(connect_factory=connect,schema=fixture_schema)
  ports=Ports(f)
  if a.phase=='before_restart':
   m.seed(connect_factory=connect,schema=fixture_schema,fixture=f)
   service=m.create_service(connect_factory=connect,schema=fixture_schema,ports=ports)
   out=service.execute(f['operation'],f['request']);assert subset(f['expect'],out),(f['name'],out)
  # brand-new service/connection, no prior in-memory cache; after server restart same identities.
  fresh=Ports(f);service=m.create_service(connect_factory=connect,schema=fixture_schema,ports=fresh)
  out=service.execute(f['operation'],f['request']);assert subset(f['repeat_expect'],out),(f['name'],'persistent replay',out)
  assert not any(n in f.get('repeat_forbidden_calls',[]) for n,r in fresh.calls),(f['name'],'effect after reload')
  print('PASS PG persistent replay',f['name'])
 if executed==0:print('PG TRANSPORT PASS; component NOT_RUN (no persistent cases)');return 3
 print('PG TRANSPORT/SCOPED COMPONENT PHASE PASS',a.phase,'; installed dependencies/native gate NOT_RUN')
 return 0
if __name__=='__main__':sys.exit(main())
